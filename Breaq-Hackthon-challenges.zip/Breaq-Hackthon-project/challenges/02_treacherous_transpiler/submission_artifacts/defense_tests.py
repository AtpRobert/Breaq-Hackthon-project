"""Reproducible, labelled challenge tests; separate from the submitted verifier."""
import numpy as np
from qiskit import AncillaRegister, QuantumCircuit, QuantumRegister, transpile
from qiskit.circuit import Gate, Parameter
from qiskit.circuit.library import UnitaryGate
from qiskit.transpiler import Layout

from .student_api import verify_compilation as standalone_verify


def run_defense_tests(verify, guarded_compile, service):
    rows = []

    def check(label, source, candidate, expected, category="semantic"):
        notebook_result = verify(source, candidate)
        module_result = standalone_verify(source, candidate)
        passed = (type(notebook_result) is bool and type(module_result) is bool
                  and notebook_result == expected and module_result == expected)
        rows.append({"test": label, "category": category, "expected_accept": expected,
                     "notebook_accept": notebook_result, "standalone_accept": module_result,
                     "passed": passed})
        assert passed, rows[-1]

    # Labels derive from the compiler investigation, not a lookup in the verifier.
    changed = {"SCAN-B", "SCAN-D", "SCAN-F"}
    for name, source in service.workloads().items():
        check("baseline/" + name, source, service.compile(source, build="baseline"), True)
        check("suspect/" + name, source, service.compile(source), name not in changed)

    h = QuantumCircuit(1)
    h.h(0)
    rewrite = QuantumCircuit(1)
    rewrite.rz(np.pi / 2, 0)
    rewrite.sx(0)
    rewrite.rz(np.pi / 2, 0)
    rewrite.global_phase += 0.31
    check("different-gate-sequence-and-global-phase", h, rewrite, True)
    phased = h.copy()
    phased.global_phase += 2.3
    phased.name = "untrusted-name"
    phased.metadata = {"infected": True, "valid": False}
    check("global-phase-and-misleading-metadata", h, phased, True)
    labelled = h.copy()
    labelled.z(0)
    labelled.name = h.name
    labelled.metadata = {"verified": True}
    check("semantic-mutation-with-innocent-label", h, labelled, False)
    identity = QuantumCircuit(1)
    relative = QuantumCircuit(1)
    relative.z(0)
    check("same-zero-output-relative-phase", identity, relative, False)
    cancelled = h.copy()
    cancelled.x(0)
    cancelled.x(0)
    cancelled.barrier()
    check("cancellation-and-barrier", h, cancelled, True)

    # Exercise every gate supported by the lab, rather than only the trigger gates.
    all_gates = QuantumCircuit(2)
    for method in ("id", "h", "x", "y", "z", "s", "sdg", "t", "tdg", "sx", "sxdg"):
        getattr(all_gates, method)(0)
    for method in ("rx", "ry", "rz", "p"):
        getattr(all_gates, method)(0.237, 1)
    all_gates.cx(0, 1)
    all_gates.cz(0, 1)
    all_gates.swap(0, 1)
    all_gates.barrier()
    check("all-supported-gates", all_gates, service.compile(all_gates, build="baseline"), True)

    rng = np.random.default_rng(2026)
    for width in range(1, 7):
        for trial in range(5):
            source = QuantumCircuit(width)
            for _ in range(12):
                wire = int(rng.integers(width))
                source.h(wire)
                source.ry(float(rng.uniform(-2, 2)), wire)
                source.rz(float(rng.uniform(-2, 2)), wire)
                if width > 1:
                    source.cx(wire, (wire + 1) % width)
            candidate = transpile(source, basis_gates=["rz", "sx", "x", "cx"],
                                  optimization_level=1, approximation_degree=1.0, seed_transpiler=2026)
            candidate.global_phase += float(rng.uniform(-3, 3))
            check(f"random/{width}/{trial}/equivalent", source, candidate, True)
            # Appending X changes every unitary as a linear map, regardless of input.
            mutation = candidate.copy()
            mutation.x(width - 1)
            check(f"random/{width}/{trial}/mutation", source, mutation, False)

    invalid = []
    measured = QuantumCircuit(1, 1)
    measured.measure(0, 0)
    invalid.append(("measurement", measured))
    classical = QuantumCircuit(1, 1)
    invalid.append(("classical-bit-without-measurement", classical))
    reset = QuantumCircuit(1)
    reset.reset(0)
    invalid.append(("reset", reset))
    symbolic = QuantumCircuit(1)
    symbolic.rz(Parameter("theta"), 0)
    invalid.append(("unbound-parameter", symbolic))
    nan_rotation = QuantumCircuit(1)
    nan_rotation.rz(float("nan"), 0)
    invalid.append(("nonfinite-parameter", nan_rotation))
    nan_phase = QuantumCircuit(1)
    nan_phase.global_phase = float("nan")
    invalid.append(("nonfinite-global-phase", nan_phase))
    too_long = QuantumCircuit(1)
    for _ in range(501):
        too_long.x(0)
    invalid.append(("more-than-500-instructions", too_long))
    fake = QuantumCircuit(1)
    fake.append(Gate("x", 1, []), [0])
    invalid.append(("custom-gate-spoofs-standard-name", fake))
    custom = QuantumCircuit(1)
    custom.append(UnitaryGate(np.eye(2)), [0])
    invalid.append(("unsupported-custom-unitary", custom))
    placed = QuantumCircuit(1)
    placed._layout = Layout({placed.qubits[0]: 0})
    invalid.append(("physical-layout", placed))
    ancilla = QuantumCircuit(QuantumRegister(1, "q"), AncillaRegister(1, "a"))
    invalid.append(("ancilla-register", ancilla))
    invalid.extend([("zero-qubits", QuantumCircuit(0)), ("seven-qubits", QuantumCircuit(7)),
                    ("wrong-type", "not a circuit"), ("none", None)])
    for label, bad in invalid:
        check("invalid-candidate/" + label, identity, bad, False, "validation")
        check("invalid-source/" + label, bad, identity, False, "validation")
    check("different-logical-width", identity, QuantumCircuit(2), False, "validation")
    maximum_length = QuantumCircuit(1)
    for _ in range(500):
        maximum_length.x(0)
    check("exactly-500-instructions", identity, maximum_length, True)

    wrapper_rows = []
    for build in ("baseline", "suspect"):
        for name, source in service.workloads().items():
            expected = build == "baseline" or name not in changed
            try:
                result = guarded_compile(service, source, build=build)
                accepted = True
                assert standalone_verify(source, result)
            except ValueError:
                accepted = False
            wrapper_rows.append({"test": f"wrapper/{build}/{name}", "expected_accept": expected,
                                 "accepted": accepted, "passed": accepted == expected})
            assert accepted == expected, wrapper_rows[-1]

    class MutatingCompiler:
        def compile(self, source, build="suspect"):
            source.x(0)
            return source

    protected = QuantumCircuit(1)
    try:
        guarded_compile(MutatingCompiler(), protected)
        refused = False
    except ValueError:
        refused = True
    assert refused and len(protected.data) == 0
    wrapper_rows.append({"test": "wrapper/compiler-mutates-supplied-copy", "expected_accept": False,
                         "accepted": not refused, "passed": refused and len(protected.data) == 0})

    class InvalidCompiler:
        def compile(self, source, build="suspect"):
            return "invalid candidate"

    try:
        guarded_compile(InvalidCompiler(), identity)
        refused = False
    except ValueError:
        refused = True
    assert refused
    wrapper_rows.append({"test": "wrapper/invalid-return", "expected_accept": False,
                         "accepted": not refused, "passed": refused})

    semantic = [row for row in rows if row["category"] == "semantic"]
    tp = sum(not row["expected_accept"] and not row["standalone_accept"] for row in semantic)
    fn = sum(not row["expected_accept"] and row["standalone_accept"] for row in semantic)
    tn = sum(row["expected_accept"] and row["standalone_accept"] for row in semantic)
    fp = sum(row["expected_accept"] and not row["standalone_accept"] for row in semantic)
    return {"positive_class": "non-equivalent in-contract candidate", "TP": tp, "FN": fn,
            "TN": tn, "FP": fp, "tests": rows, "wrapper_tests": wrapper_rows,
            "validation_rejections": sum(row["category"] == "validation" for row in rows),
            "all_passed": all(row["passed"] for row in rows + wrapper_rows),
            "random_seed": 2026, "random_equivalent_pairs": 30, "random_mutations": 30}
