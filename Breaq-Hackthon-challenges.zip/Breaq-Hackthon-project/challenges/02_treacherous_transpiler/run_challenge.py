"""Execute the complete notebook, then rebuild its report and submission ZIP.

Run from the challenge environment: .venv/bin/python run_challenge.py
All generated Jupyter configuration and runtime files stay in this environment.
"""
import os
from pathlib import Path
import subprocess
import sys


def main():
    root = Path(__file__).resolve().parent
    os.chdir(root)
    for name, relative in {
        "IPYTHONDIR": ".venv/ipython",
        "JUPYTER_CONFIG_DIR": ".venv/jupyter-config",
        "JUPYTER_RUNTIME_DIR": ".venv/jupyter-runtime",
        "MPLCONFIGDIR": ".venv/matplotlib",
    }.items():
        directory = root / relative
        directory.mkdir(parents=True, exist_ok=True)
        os.environ[name] = str(directory)
    from ipykernel.kernelspec import install
    import nbformat
    from nbclient import NotebookClient

    install(prefix=sys.prefix, kernel_name="breaq-ch2", display_name="BreaQ CH2 (Qiskit 2.2.3)")
    path = root / "02_treacherous_transpiler.ipynb"
    notebook = nbformat.read(path, as_version=4)
    client = NotebookClient(notebook, timeout=240, kernel_name="breaq-ch2",
                            resources={"metadata": {"path": str(root)}})
    try:
        client.execute()
    finally:
        nbformat.write(notebook, path)
    nbformat.validate(notebook)
    cells = [cell for cell in notebook.cells if cell.cell_type == "code"]
    assert all(cell.execution_count is not None for cell in cells)
    assert not any(output.output_type == "error" for cell in cells for output in cell.outputs)
    print(f"Executed all {len(cells)} notebook code cells without errors.", flush=True)
    resolved = subprocess.check_output([sys.executable, "-m", "pip", "freeze"], text=True)
    (root / "submission_artifacts/requirements-resolved.txt").write_text(resolved)
    subprocess.run([sys.executable, str(root / "build_report.py")], check=True)


if __name__ == "__main__":
    main()
