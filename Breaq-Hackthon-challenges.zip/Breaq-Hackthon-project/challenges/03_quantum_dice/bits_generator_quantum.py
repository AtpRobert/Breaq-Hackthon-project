"""Generate clean and classically sticky bit streams for a dice experiment.

The clean source repeatedly prepares |0>, applies H, and samples the resulting
statevector distribution. These ordered samples model repeated preparation
and measurement, not one measurement copied into a batch. Qiskit's simulator
uses pseudorandom sampling: this is not physical quantum entropy and must not
be used to generate cryptographic keys.

The sticky source applies a classical service-layer fault after quantum
simulation. Each bit copies the previous output with probability p; otherwise
it uses a fresh unbiased quantum-simulated candidate. With p=0.8, the chance
of repeating the previous bit is 0.8 + 0.2 * 0.5 = 0.9. Every position remains
marginally 50/50 only when the starting bit is itself unbiased. When the
terminal input fixes the starting bit, the distribution approaches 50/50 over
time; adjacent bits remain dependent. Counts are not forced to be exactly equal.
"""

import argparse
import csv
import json
from pathlib import Path
from typing import Protocol

import numpy as np
import qiskit
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector


class BitSource(Protocol):
	def generate_batch(self, n_bits: int) -> list[int]:
		"""Generate an ordered batch of zero/one bits."""


class CleanSource:
	"""Repeated Hadamard preparation sampled by a persistent Qiskit RNG."""

	def __init__(self, seed: int) -> None:
		circuit = QuantumCircuit(1)
		circuit.h(0)
		self._state = Statevector.from_instruction(circuit)
		self._state.seed(seed)

	def generate_batch(self, n_bits: int) -> list[int]:
		if n_bits < 0:
			raise ValueError("n_bits must not be negative")
		return [int(sample) for sample in self._state.sample_memory(shots=n_bits)]


class StickySource:
	"""Classical sticky fault applied to fresh clean-source candidate bits."""

	def __init__(self, candidate_source: BitSource, copy_probability: float,
			 seed: int, initial_bit: int) -> None:
		self._candidate_source = candidate_source
		self._copy_probability = copy_probability
		self._copy_rng = np.random.default_rng(seed)
		self._previous_bit: int | None = initial_bit
		self._initial_bit = initial_bit
		self._started = False

	def generate_batch(self, n_bits: int) -> list[int]:
		if n_bits < 0:
			raise ValueError("n_bits must not be negative")
		if n_bits == 0:
			return []

		starts_with_initial = not self._started
		candidate_count = n_bits - int(starts_with_initial)
		candidates = iter(self._candidate_source.generate_batch(candidate_count))
		output: list[int] = []
		if starts_with_initial:
			output.append(self._initial_bit)
			self._started = True

		for candidate in candidates:
			if self._copy_rng.random() < self._copy_probability:
				bit = self._previous_bit
			else:
				bit = candidate
			output.append(bit)
			self._previous_bit = bit
		return output


def _read_initial_bit() -> int:
	while True:
		value = input("Enter the initial sticky bit (0 or 1): ").strip()
		if value in {"0", "1"}:
			return int(value)
		print("Please enter exactly 0 or 1.")


def _positive_int(value: str) -> int:
	try:
		parsed = int(value)
	except ValueError as error:
		raise argparse.ArgumentTypeError("must be an integer") from error
	if parsed <= 0:
		raise argparse.ArgumentTypeError("must be greater than zero")
	return parsed


def _seed_assignments(seed: int) -> dict[str, int]:
	children = np.random.SeedSequence(seed).spawn(3)
	labels = ("clean_quantum", "sticky_candidate_quantum", "sticky_copy_decisions")
	return {
		label: int(child.generate_state(1, dtype=np.uint32)[0])
		for label, child in zip(labels, children)
	}


def _write_samples(path: Path, batches: list[list[int]]) -> None:
	with path.open("w", newline="", encoding="utf-8") as csv_file:
		writer = csv.writer(csv_file)
		writer.writerow(("batch_id", "bit_index", "bit"))
		for batch_id, bits in enumerate(batches, start=1):
			for bit_index, bit in enumerate(bits):
				writer.writerow((batch_id, bit_index, bit))


def _parse_args() -> argparse.Namespace:
	parser = argparse.ArgumentParser(
		description="Generate ordered clean and sticky quantum-dice experiment samples."
	)
	parser.add_argument("--bits-per-batch", type=_positive_int, default=100)
	parser.add_argument("--batches", type=_positive_int, default=10)
	parser.add_argument("--seed", type=int, default=42,
					 help="non-negative root seed for reproducible sources (default: 42)")
	parser.add_argument("--copy-probability", type=float, default=0.8,
					 help="sticky-source copy probability between 0 and 1 (default: 0.8)")
	parser.add_argument("--output-dir", type=Path, default=Path("output"))
	args = parser.parse_args()
	if args.seed < 0:
		parser.error("--seed must be non-negative")
	if not 0.0 <= args.copy_probability <= 1.0:
		parser.error("--copy-probability must be between 0 and 1")
	return args


def main() -> None:
	args = _parse_args()
	initial_bit = _read_initial_bit()
	args.output_dir.mkdir(parents=True, exist_ok=True)
	seeds = _seed_assignments(args.seed)

	clean_source = CleanSource(seeds["clean_quantum"])
	sticky_source = StickySource(
		candidate_source=CleanSource(seeds["sticky_candidate_quantum"]),
		copy_probability=args.copy_probability,
		seed=seeds["sticky_copy_decisions"],
		initial_bit=initial_bit,
	)

	clean_batches = [clean_source.generate_batch(args.bits_per_batch)
					 for _ in range(args.batches)]
	sticky_batches = [sticky_source.generate_batch(args.bits_per_batch)
					 for _ in range(args.batches)]
	_write_samples(args.output_dir / "clean.csv", clean_batches)
	_write_samples(args.output_dir / "sticky.csv", sticky_batches)

	metadata = {
		"configuration": {
			"bits_per_batch": args.bits_per_batch,
			"batches": args.batches,
			"initial_sticky_bit": initial_bit,
			"copy_probability": args.copy_probability,
			"effective_repeat_probability": (
				args.copy_probability + (1 - args.copy_probability) * 0.5
			),
			"output_dir": str(args.output_dir),
			"bit_indexing": "zero-based within each batch",
			"batch_id_indexing": "one-based",
		},
		"root_seed": args.seed,
		"seed_assignments": seeds,
		"library_versions": {"qiskit": qiskit.__version__, "numpy": np.__version__},
		"state_persists_across_requests": {
			"clean_quantum_rng": True,
			"sticky_candidate_quantum_rng": True,
			"sticky_copy_rng": True,
			"sticky_previous_output_bit": True,
		},
		"sticky_source_note": (
			"Classical service-layer fault after quantum simulation; not a physical quantum effect."
		),
		"entropy_note": (
			"Simulator output uses pseudorandom sampling, not physical quantum entropy; "
			"do not use it for cryptographic keys."
		),
	}
	with (args.output_dir / "metadata.json").open("w", encoding="utf-8") as json_file:
		json.dump(metadata, json_file, indent=2)
		json_file.write("\n")

	print(f"Wrote {args.batches * args.bits_per_batch} bits per source to {args.output_dir}")


if __name__ == "__main__":
	main()
