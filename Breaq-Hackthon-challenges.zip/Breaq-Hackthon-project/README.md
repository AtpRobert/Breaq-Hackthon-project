# BreaQ hackathon challenge files

Organized copies of the solutions and results from the local workspace.

| Folder | Challenge | Main files |
| --- | --- | --- |
| challenges/01_trust_no_input | CH1: Trust No Input | 01_solution.ipynb, ANSWERS.txt, results/ |
| challenges/02_treacherous_transpiler | CH2: The Treacherous Transpiler | completed notebook, CHALLENGE_REPORT.txt, submission.json, submission_artifacts/ |
| challenges/03_quantum_dice | Quantum Dice | generator, verifier, CSV data and fairness_plot.png |
| challenges/04_bb84 | Catch the Eavesdropper | Bob, channel simulator, experiment runner and results/ |
| challenges/05_shor_in_miniature | Shor | teaching simulator and modular-period plot |
| challenges/06_hardware_surprise | Hardware Surprise | documentation-status figure only |

CH1 and CH2 are different from the separate Shor PDF also labelled Challenge 2.
The Shor file is a teaching simulator, not a complete circuit-level challenge submission.
The public hardware brief and measurements are unavailable, so no hardware solution is claimed.
All recorded experimental results are local simulations.

Keep each challenge's modules and instance configuration together. Install its requirements
in a separate virtual environment before running notebooks or scripts. The upstream Apache
2.0 license is preserved. See ATTRIBUTION.md for sources.

This collection excludes virtual environments, Python caches, credentials and editor files.
