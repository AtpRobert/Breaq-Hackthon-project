"""A small, dependency-free simulator for Shor-style factoring examples.

The period-finding step samples the exact measurement distribution obtained
from modular exponentiation followed by an inverse quantum Fourier transform.
It is a mathematical simulation, not a circuit running on quantum hardware,
and is intended for small demonstration inputs.
"""

import argparse
import math
import random
from fractions import Fraction


def _inverse_fft(amplitudes: list[complex]) -> list[complex]:
	"""Apply the inverse discrete Fourier transform in O(n log n)."""
	size = len(amplitudes)
	result = amplitudes.copy()
	reversed_index = 0

	for index in range(1, size):
		bit = size >> 1
		while reversed_index & bit:
			reversed_index ^= bit
			bit >>= 1
		reversed_index ^= bit
		if index < reversed_index:
			result[index], result[reversed_index] = result[reversed_index], result[index]

	width = 2
	while width <= size:
		root = complex(math.cos(2 * math.pi / width), math.sin(2 * math.pi / width))
		half_width = width // 2
		for start in range(0, size, width):
			phase = 1 + 0j
			for offset in range(half_width):
				even = result[start + offset]
				odd = result[start + offset + half_width] * phase
				result[start + offset] = even + odd
				result[start + offset + half_width] = even - odd
				phase *= root
		width *= 2

	return result


def _sample_phase(base: int, modulus: int, register_size: int,
				  rng: random.Random) -> int:
	"""Simulate modular-exponentiation measurement and inverse QFT."""
	measured_x = rng.randrange(register_size)
	measured_value = pow(base, measured_x, modulus)
	collapsed = [
		1 + 0j if pow(base, x, modulus) == measured_value else 0j
		for x in range(register_size)
	]
	norm = math.sqrt(sum(amplitude.real for amplitude in collapsed))
	collapsed = [amplitude / norm for amplitude in collapsed]
	transformed = _inverse_fft(collapsed)
	probabilities = [abs(amplitude) ** 2 for amplitude in transformed]
	return rng.choices(range(register_size), weights=probabilities, k=1)[0]


def _find_order(base: int, modulus: int, register_size: int,
				shots: int, rng: random.Random) -> int | None:
	for _ in range(shots):
		phase = _sample_phase(base, modulus, register_size, rng)
		fraction = Fraction(phase, register_size).limit_denominator(modulus)
		denominator = fraction.denominator

		for multiplier in range(1, modulus // denominator + 1):
			candidate = denominator * multiplier
			if pow(base, candidate, modulus) == 1:
				return candidate

	return None


def verify_perfect_power(n: int) -> tuple[int, int]:
	"""Return ``(base, 1)`` if n is a perfect power, otherwise ``(n, 0)``."""
	if not isinstance(n, int) or isinstance(n, bool):
		raise TypeError("n must be an integer")
	if n < 1:
		raise ValueError("n must be positive")
	if n == 1:
		return 1, 1

	for exponent in range(n.bit_length() - 1, 1, -1):
		low = 2
		high = 1 << ((n.bit_length() + exponent - 1) // exponent)
		while low <= high:
			base = (low + high) // 2
			power = base ** exponent
			if power == n:
				return base, 1
			if power < n:
				low = base + 1
			else:
				high = base - 1

	return n, 0


def verify_odd_prime_power(n: int) -> tuple[int, int]:
	"""Return ``(p, 1)`` when n is p**k for an odd prime p and k > 1."""
	if not isinstance(n, int) or isinstance(n, bool):
		raise TypeError("n must be an integer")
	if n < 1:
		raise ValueError("n must be positive")

	for exponent in range(n.bit_length() - 1, 1, -1):
		low = 3
		high = 1 << ((n.bit_length() + exponent - 1) // exponent)
		while low <= high:
			base = (low + high) // 2
			if base % 2 == 0:
				base += 1
			if base > high:
				high = (low + high) // 2 - 1
				continue
			power = base ** exponent
			if power == n:
				is_prime = all(base % divisor for divisor in range(3, math.isqrt(base) + 1, 2))
				if is_prime:
					return base, 1
				break
			if power < n:
				low = base + 2
			else:
				high = base - 2

	return n, 0


def factor(n: int, shots: int = 8, max_attempts: int = 20,
		   seed: int | None = None) -> tuple[int, int] | None:
	"""Return a non-trivial factor pair, or None if the randomized search fails.

	The simulator is intended for small composites. ``seed`` can be supplied
	to make its randomized choices repeatable.
	"""
	if not isinstance(n, int) or isinstance(n, bool):
		raise TypeError("n must be an integer")
	if n < 2:
		raise ValueError("n must be at least 2")
	if shots < 1 or max_attempts < 1:
		raise ValueError("shots and max_attempts must be positive")

	if n % 2 == 0:
		return (2, n // 2) if n > 2 else None

	base, is_power = verify_perfect_power(n)
	if is_power:
		return base, n // base

	register_bits = 2 * (n - 1).bit_length()
	if register_bits > 16:
		raise ValueError("this teaching simulator supports inputs up to 16 phase qubits")
	register_size = 1 << register_bits
	rng = random.Random(seed)

	for _ in range(max_attempts):
		base = rng.randrange(2, n)
		common_divisor = math.gcd(base, n)
		if common_divisor > 1:
			return common_divisor, n // common_divisor

		order = _find_order(base, n, register_size, shots, rng)
		if order is None or order % 2:
			continue

		half_power = pow(base, order // 2, n)
		if half_power == n - 1:
			continue

		for candidate in (math.gcd(half_power - 1, n),
						  math.gcd(half_power + 1, n)):
			if 1 < candidate < n:
				return candidate, n // candidate

	return None


def main() -> None:
	parser = argparse.ArgumentParser(description="Factor a small integer with Shor's algorithm simulation.")
	parser.add_argument("n", type=int, help="integer to factor")
	parser.add_argument("--shots", type=int, default=8, help="phase measurements per base (default: 8)")
	parser.add_argument("--attempts", type=int, default=20, help="random bases to try (default: 20)")
	parser.add_argument("--seed", type=int, help="seed for repeatable results")
	args = parser.parse_args()

	result = factor(args.n, shots=args.shots, max_attempts=args.attempts, seed=args.seed)
	if result is None:
		print(f"Could not find a non-trivial factor of {args.n}.")
	else:
		print(f"{args.n} = {result[0]} * {result[1]}")


if __name__ == "__main__":
	main()
