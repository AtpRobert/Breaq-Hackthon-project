"""Validate saved results, write the requested text report, and package submission."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import zipfile


def main():
    root = Path(__file__).resolve().parent
    artifacts = root / "submission_artifacts"
    evidence = json.loads((artifacts / "full_evidence.json").read_text())
    submission = json.loads((root / "submission.json").read_text())
    notebook = json.loads((root / "02_treacherous_transpiler.ipynb").read_text())
    code_cells = [cell for cell in notebook["cells"] if cell["cell_type"] == "code"]
    assert all(cell["execution_count"] is not None for cell in code_cells)
    assert not any(out["output_type"] == "error" for cell in code_cells for out in cell["outputs"])
    assert all(submission["completion_status"].values())
    defense = evidence["defense"]
    assert defense["all_passed"] and defense["FN"] == defense["FP"] == 0
    assert defense["new_reproducer_refused"]
    assert all(row["passed"] for row in defense["tests"] + defense["wrapper_tests"])
    assert all(row["predicted_mismatch"] == row["observed_mismatch"]
               for row in evidence["trigger_experiments"] + evidence["generalization_experiments"])
    expected_hashes = json.loads((artifacts / "organizer_files_sha256.json").read_text())
    for relative, expected in expected_hashes.items():
        assert hashlib.sha256((root / relative).read_bytes()).hexdigest() == expected, relative
    # Verify the notebook contains precisely the standalone implementation prefix.
    standalone = (artifacts / "student_api.py").read_text()
    notebook_verifier = "".join(notebook["cells"][23]["source"])
    assert notebook_verifier.startswith(standalone.rstrip())
    module_ast = ast.parse(standalone)
    assert all(not isinstance(node, ast.ImportFrom) or node.module not in ("breaq_ch2", "breaq_ch2.service")
               for node in ast.walk(module_ast))
    expected_counts = {
        "comparison.csv": len(evidence["core"]["comparison"]),
        "triage.csv": len(evidence["core"]["triage"]),
        "stages.csv": len(evidence["core"]["stage_evidence"]),
        "trigger.csv": len(evidence["trigger_experiments"]),
        "generalization.csv": len(evidence["generalization_experiments"]),
        "minimization.csv": len(evidence["reproducer"]["minimization_trials"]),
        "witness.csv": 3,
        "defense_tests.csv": len(defense["tests"]),
        "wrapper_tests.csv": len(defense["wrapper_tests"]),
        "angle_sweep.csv": len(evidence["angle_sweep"]),
    }
    for name, count in expected_counts.items():
        with (artifacts / name).open(newline="") as handle:
            assert len(list(csv.DictReader(handle))) == count, name
    # A hash identifies an artifact, never whether the circuit is correct.
    assert hashlib.sha256((artifacts / "minimal_source.qpy").read_bytes()).hexdigest() == evidence["reproducer"]["source_digest"]
    repro = evidence["reproducer"]
    extensions = evidence["extensions"]
    comparisons = evidence["core"]["comparison"]
    suspect = [row for row in comparisons if row["build"] == "suspect"]
    versions = evidence["environment"]
    source_witness = next(row for row in repro["witness_rows"] if row["build"] == "source")
    candidate_witness = next(row for row in repro["witness_rows"] if row["build"] == "suspect")
    lines = [
        "BREAQ 2026 - CHALLENGE 2: THE TREACHEROUS TRANSPILER",
        "COMPLETE LOCAL INVESTIGATION REPORT",
        "=" * 72,
        "",
        "1. OUTCOME AND SCOPE",
        "",
        "Completed the core investigation, a new minimized reproducer and observable",
        "witness, an independent verification gate, its refusal wrapper, negative and",
        "positive tests, advanced experiments, and the local submission export.",
        "All results are LOCAL SIMULATION. This is the deliberately vulnerable lab",
        "compiler, not a discovered vulnerability in Qiskit or a real vendor.",
        f"Configuration: team_id={submission['team_id']}, instance_seed={submission['instance_seed']}.",
        "The repository's DEMO-TEAM configuration was preserved; no real event team",
        "identifier was invented. Source reading was permitted and used. The work",
        "does not claim blind discovery or a formal mathematical proof.",
        "",
        "2. WHAT WAS SET UP AND PRESERVED",
        "",
        "Downloaded all six original Challenge 2 files into BreaQ 2026 CH2.",
        "Created a separate .venv rather than modifying the parent project's environment.",
        f"Python: {versions['python']}.",
        "Installed versions: " + ", ".join(f"{k}={v}" for k, v in versions['packages'].items()) + ".",
        "Registered a local BreaQ CH2 (Qiskit 2.2.3) notebook kernel.",
        "The original compiler source, package initializer, requirements, START_HERE",
        "and team_instance.json are unchanged. Their bytes were checked against the",
        "downloaded repository archive and their SHA-256 hashes were recorded.",
        "The notebook and new investigation/submission files contain our solution.",
        "",
        "3. THE PROBLEM IN PLAIN LANGUAGE",
        "",
        "A compiler may replace a circuit with a different-looking circuit, but the",
        "new circuit must still perform the same operation on every possible input.",
        "A shorter circuit is not necessarily correct. Matching one histogram is",
        "also insufficient, because phases and behavior on other inputs can differ.",
        "The lab allows one overall global phase: multiplying the WHOLE unitary by",
        "exp(i*phi) does not change a standalone experiment. Different phases for",
        "different states or matrix columns are not generally harmless.",
        "",
        "4. CORE INVESTIGATION: ALL SUPPLIED WORKLOADS",
        "",
        "Before calculating the exact table, recorded source-informed predictions:",
        "relative phases can hide in histograms; one input state can hide an operator",
        "change; legitimate rewrites/global phases should pass; baseline should pass.",
        "For both compiler builds and all eight workloads, measured gate count,",
        "depth, exact Z-basis probability distance, zero-input state fidelity, full",
        "unitary equivalence, and a global-phase-aligned matrix error.",
        "Repeated sampled triage with 512 shots and seed 2026; normalized counts",
        "before calculating sampled total-variation distances.",
        "",
        "TV(P,Q) = 0.5 * sum_x |P(x)-Q(x)|. Zero means matching probabilities.",
        "Fidelity = |<psi_source|psi_candidate>|^2. One means the same pure output",
        "state up to global phase for that particular input.",
        "",
        "Suspect-build results (tiny floating-point distances rounded for display):",
        "Workload                TV distance     Zero-state fidelity   Equivalent",
    ]
    for row in suspect:
        lines.append(f"{row['case_id']:<23} {row['exact_tv']:>12.8f} {row['zero_state_fidelity']:>23.8f}   {row['unitary_equivalent']}")
    lines += [
        "",
        "Every baseline workload is equivalent. Suspect SCAN-B, SCAN-D and SCAN-F",
        "are not. SCAN-D has matching Z probabilities but a different output state.",
        "SCAN-F even has matching zero-input output state, but a different full",
        "operation. Both are counterexamples to incomplete semantic checkers.",
        "Gate counts and depth are saved in comparison.csv; they are performance",
        "statistics, not certificates of integrity.",
        "",
        "5. FAULT LOCALIZATION AND ROOT CAUSE",
        "",
        "Recorded and compared each stage against both its previous stage and the",
        "source for both builds: 72 stage records in stages.csv.",
        "First failing transition for SCAN-B:",
        "  " + submission["first_bad_transition"],
        "Normalization preserves semantics. Adding pi/7 global phase also preserves",
        "the standalone operation. The vendor stage changes the operation; later",
        "native-basis lowering preserves that already compromised operation.",
        "",
        "Source inspection identifies _EchoBalance.run in breaq_ch2/service.py:",
        "  CX(control,target) -> RZ(theta,target) -> CX(control,target)",
        "When those operations are adjacent ON THE TARGET WIRE and use the same",
        "ordered CX pair, the plugin may substitute RZ(-theta) for RZ(theta).",
        "Only the first eligible match is changed.",
        "",
        "Source-derived numeric condition:",
        "  lower = 0.25 + 0.025 * (seed % 7)",
        "  upper = lower + 0.50",
        f"For this seed: {extensions['source_derived_inclusive_interval']} radians, endpoints inclusive.",
        "The sign substitution is supported by measured adjacent-stage operators",
        "and a concrete probability counterexample, not just a stage-name label.",
        "Attribution assumes faithful local trace instrumentation. A remote compiler",
        "could lie about its trace; its labels would not attest its real execution.",
        "",
        "6. CONTROLLED TRIGGER AND GENERALIZATION EXPERIMENTS",
        "",
        f"Ran {len(evidence['trigger_experiments'])} build comparisons covering 19 angle/structure cases.",
        "Tested angles just below, exactly at and inside the interval, exactly at the",
        "upper endpoint and just above it; also zero, negative and theta+2*pi.",
        "Changed one structural feature at a time: rotation on control versus target,",
        "reversed control/target roles, spectator operation, barrier, target identity",
        "gate, PhaseGate instead of RZ, different second control, rotation position,",
        "and input preparation. Each case included the trusted baseline control.",
        "Unrelated-wire gates do not break target-wire adjacency. Barriers disappear",
        "before the plugin. An identity on the target interrupts its syntactic pattern.",
        "Preparing a different state changes observability, not this trigger rule.",
        f"Ran {len(evidence['generalization_experiments'])} comparisons across seven temporary public-instance",
        "seeds, covering all seed residues modulo seven and testing both builds.",
        "Every recorded trigger/non-trigger prediction matched observation.",
        "Original team_instance.json was never modified for these experiments.",
        "",
        "7. A NEW MINIMAL REPRODUCER",
        "",
        f"Selected theta={repro['angle']} radians, different from the supplied workload center.",
        "Built a new 3-qubit, 9-instruction source and repeatedly deleted instructions",
        "only when full-unitary mismatch remained. Then removed the idle wire.",
        f"Saved all {len(repro['minimization_trials'])} deletion trials, including deletion of each final gate.",
        "Final source: two qubits, three gates:",
        "  qc = QuantumCircuit(2)",
        "  qc.cx(0, 1)",
        f"  qc.rz({repro['angle']}, 1)",
        "  qc.cx(0, 1)",
        "Removing any one of the final gates prevents this mismatch. A one-wire",
        "rotation control also passes. The known rule requires two CX gates and one",
        "RZ, hence at least two wires; no universal minimum for all attacks is claimed.",
        "The bare circuit has identical zero-input probabilities and fidelity one,",
        "yet different full operators. Source and candidate even have the same three",
        "gate count and depth, illustrating that cost statistics cannot certify meaning.",
        "Saved the source as minimal_source.qpy and minimal_source.txt.",
        "",
        "8. MAKING THE CHANGE OBSERVABLE",
        "",
        "Compiled ONLY the bare three-gate subroutine. Applied trusted preparation",
        "H(q1) before it and trusted analysis Sdg(q1), H(q1) after it, then measured.",
        "These preparation/analysis operations were not handed to the compiler.",
        "Control q0 stays zero and target q1 starts in |+>. The analysis measures Y",
        "using a final Z measurement, revealing the rotation sign.",
        "Displayed strings are ordered q1 q0:",
        "  Source:  P(00)=(1+sin(theta))/2; P(10)=(1-sin(theta))/2.",
        "  Suspect: those two probabilities are exchanged.",
        f"Measured source probabilities:  {source_witness['probabilities']}",
        f"Measured suspect probabilities: {candidate_witness['probabilities']}",
        f"Exact witness TV: {repro['trusted_witness']['exact_tv']:.12f} = |sin(theta)|.",
        f"Sampled {source_witness['shots']} shots per circuit with seed {source_witness['seed']}:",
        f"  Source counts:  {source_witness['counts']}",
        f"  Suspect counts: {candidate_witness['counts']}",
        "The baseline reproduces the source probabilities. Sample counts are",
        "supporting observations; the exact operator/probability calculations establish",
        "the modeled semantic mismatch without a sampling significance claim.",
        "",
        "9. INDEPENDENT VERIFIER AND REFUSAL WRAPPER",
        "",
        "submission_artifacts/student_api.py exposes verify_compilation(source, candidate).",
        "It imports no notebook, compiler service, case labels or trigger logic.",
        "It does not use names, metadata, stage labels, gate counts or hashes to",
        "decide whether computations are equivalent.",
        "Validation checks both arguments: QuantumCircuit; 1-6 qubits; no ancillas,",
        "classical bits, layout or unbound parameters; at most 500 instructions;",
        "finite numeric parameters/global phase; permitted standard gate classes",
        "and arities. A custom gate with a borrowed standard name is rejected.",
        "Within the lab's supported standard gate set, legitimate rewrites are allowed.",
        "The verifier constructs U and V, verifies finite entries and unitarity, then",
        "computes z=sum(conjugate(U_ij)*V_ij) and g=z/|z|. It accepts only when",
        "V and g*U agree entry by entry with absolute and relative tolerance 1e-9.",
        "One common phase is used for the whole matrix, not one per column.",
        "Validation errors and numerical/construction exceptions return False.",
        "The notebook contains the identical implementation, checked against the",
        "standalone file during report generation.",
        "",
        "guarded_compile first validates the source and keeps a protected copy.",
        "The compiler receives another copy. Its result is copied and independently",
        "verified against the protected original. Failure raises ValueError and no",
        "candidate is returned for execution. Tested a compiler that mutates its input",
        "and one that returns a non-circuit; both are refused. The caller's source",
        "remains intact in the mutation test.",
        "",
        "10. DEFENSE TEST RESULTS",
        "",
        f"Ran {len(defense['tests'])} labelled cases against BOTH notebook and standalone verifiers.",
        f"Ran {len(defense['wrapper_tests'])} additional labelled wrapper cases.",
        "Also checked that the new reproducer is refused and its baseline accepted.",
        "Cases include every supplied build/workload, equivalent gate decompositions,",
        "global phases, identity/cancellation, misleading metadata, relative-phase",
        "mutations invisible on zero input, every supported gate type, all widths",
        "from one to six, and exactly 500 versus more than 500 instructions.",
        "Generated 30 deterministic random source/rewrite pairs across 1-6 qubits",
        "and 30 deliberately mutated outputs by appending X. Those labels follow",
        "from construction, rather than a workload-name classifier in the verifier.",
        "Invalid cases include measurement, unused classical bits, reset, unbound",
        "parameters, NaN parameters/global phase, custom gates, physical layout,",
        "ancillas, zero/seven qubits, None, wrong types and incompatible widths.",
        "Each malformed circuit is tested on both the source and candidate side.",
        "",
        "Positive class: a non-equivalent in-contract candidate.",
        f"  True positives (mismatches rejected): {defense['TP']}",
        f"  False negatives (mismatches accepted): {defense['FN']}",
        f"  True negatives (equivalent pairs accepted): {defense['TN']}",
        f"  False positives (equivalent pairs rejected): {defense['FP']}",
        f"Separately rejected {defense['validation_rejections']} invalid-input pairs.",
        "All labelled tests passed. These are finite-suite results, not a universal",
        "accuracy guarantee. Both implementations share the same underlying trusted",
        "math routines; they are not two independent mathematical proofs.",
        "",
        "11. ADVANCED EXTENSIONS",
        "",
        f"Swept 241 angles from 0 to 1.2 radians at resolution {extensions['sweep_resolution_radians']},",
        f"testing both builds ({len(evidence['angle_sweep'])} rows).",
        f"Sampled suspect activation range: {extensions['sampled_active_range']} radians.",
        "A sampled grid alone cannot prove exact boundaries. Inclusive endpoints",
        "come from source logic plus separate exact-endpoint and epsilon controls.",
        "angle_sweep.png plots exactly the exported angle_sweep.csv measurements.",
        "RZ(theta) and P(theta) submissions implement the same operation up to global",
        "phase, but only the RZ syntax activates this plugin. The equivalent theta+2*pi",
        "representation also avoids its numeric interval. This diagnoses syntax",
        "sensitivity; it is not presented as a general defense.",
        "A double-pattern circuit confirms that only the first rotation flips.",
        "Discussed bounded local translation checks and symbolic/decision-diagram",
        "methods as scalability directions, without implementing or claiming a",
        "production-scale proof. Heuristic local sampling may miss cross-region phases.",
        "",
        "12. LIMITATIONS AND TRUST ASSUMPTIONS",
        "",
    ]
    lines.extend("- " + limitation for limitation in submission["verifier_limitations"])
    lines += [
        "- Stage localization additionally trusts the local trace snapshots.",
        "- This submission does not run on hardware or test a noise model.",
        "- A global phase may become observable if the whole subroutine is coherently",
        "  controlled; that is outside the standalone-unitary contract.",
        "- Layout remapping or ancillas require a different semantic comparison.",
        "- Oral defense and any official team-ID assignment remain human/event tasks.",
        "",
        "13. FILES CREATED OR UPDATED",
        "",
        "02_treacherous_transpiler.ipynb: completed solution with saved execution outputs.",
        "submission.json: exported claims, threat model, results and all completion flags.",
        "CHALLENGE_REPORT.txt: this plain-text explanation of the complete work.",
        "BreaQ_CH2_submission.zip: portable local submission bundle; no .venv/cache data.",
        "run_challenge.py: executes the notebook and rebuilds report/archive.",
        "build_report.py: validates saved evidence and packages the submission.",
        "submission_artifacts/student_api.py: standalone independent verifier.",
        "submission_artifacts/defense_tests.py: reproducible labelled test suite.",
        "submission_artifacts/full_evidence.json: all recorded experimental results.",
        "submission_artifacts/core_evidence.json: detailed core-stage evidence.",
        "submission_artifacts/minimal_source.qpy and .txt: minimized source circuit.",
        "submission_artifacts/angle_sweep.png: measured attack/witness curve.",
        "submission_artifacts/requirements-resolved.txt: exact installed package versions.",
        "submission_artifacts/organizer_files_sha256.json: preserved organizer-file hashes.",
        "submission_artifacts/artifact_manifest.json: final bundle file integrity hashes.",
        "",
        "CSV evidence row counts:",
    ]
    lines.extend(f"  {name}: {count}" for name, count in expected_counts.items())
    lines += [
        "",
        "14. REPRODUCE AND REVIEW",
        "",
        "From the BreaQ 2026 CH2 directory:",
        "  source .venv/bin/activate",
        "  python run_challenge.py",
        "",
        "On a fresh machine, first use Python 3.10-3.13 to create .venv and install",
        "requirements.txt. Qiskit must be 2.2.3. requirements-resolved.txt records",
        "the actual resolved environment; initial package installation needs internet.",
        "The experiments themselves are local and require no API token or cloud account.",
        "The runner needs permission to start local Jupyter kernel sockets.",
        f"Notebook validation: all {len(code_cells)} code cells executed without errors.",
        "The report builder checks completion flags, tests, CSV counts, source preservation,",
        "standalone/notebook verifier agreement and the saved QPY digest before packaging.",
        "To inspect interactively: python -m jupyter lab, then open the notebook and",
        "select BreaQ CH2 (Qiskit 2.2.3). Export is enabled because required fields",
        "and measured tests are now complete. No external submission was uploaded.",
        "",
        "15. ORAL-DEFENSE NOTES",
        "",
        "Different gates can multiply to the same operator, so syntax is not semantics.",
        "Matching a Z histogram loses phase information. Matching one output state",
        "also leaves behavior on other inputs unchecked. The full operator addresses",
        "both issues within this deliberately small contract.",
        "A sign change need not affect every experiment: the bare zero-input reproducer",
        "hides it. The trusted H preparation and Y-basis analysis reveal it.",
        "Normalization/global phase pass the comparison; vendor angle reversal fails.",
        "An unrelated spectator should not deactivate target-wire adjacency. Moving the",
        "RZ to the control wire or outside the interval should deactivate this trigger.",
        "The verifier accepts one global phase, rejects unsupported/wider circuits, and",
        "does not account for physical wire remapping or added ancillas.",
        "If the adversary controls the simulator, verifier or runtime, the trust model",
        "is broken; these local measurements cannot independently establish integrity.",
        "A presentation can show: the notebook threat-model diagram, the three-gate",
        "reproducer, witness probabilities or angle plot, verifier refusal, and the",
        "six-qubit/numerical/trusted-runtime limitation.",
        "",
        "16. ATTRIBUTION AND SOURCES",
        "",
        "Robert requested the investigation and deliverables. Codex implemented and",
        "executed the code, experiments, tests, evidence export and this report.",
        "The supplied hint text and source code were read; no independent human",
        "experimentation, unverified team members or competition score is claimed.",
        "Primary lab sources: START_HERE.md, the supplied notebook, team_instance.json",
        "and breaq_ch2/service.py in RoQTeam/BreaQ-2026-challenges/BreaQ 2026 CH2.",
        "Qiskit operator equivalence reference:",
        "https://quantum.cloud.ibm.com/docs/en/api/qiskit/2.2/qiskit.quantum_info.Operator",
        "The notebook also preserves the organizer's research/API provenance links.",
        "",
        "Completion is based on local execution and the supplied contract. Organizer",
        "grading and the team's ability to explain/predict jury perturbations are",
        "outside what this report can establish.",
    ]
    report = root / "CHALLENGE_REPORT.txt"
    report.write_text("\n".join(lines) + "\n", encoding="utf-8")
    (root / "CORE_PROGRESS.md").write_text(
        "# Challenge 2 progress\n\nSteps 1-3 and the remaining investigation are complete locally.\n\n"
        "See [CHALLENGE_REPORT.txt](CHALLENGE_REPORT.txt) for the full measured results,\n"
        "limitations, artifact list and reproduction instructions.\n\n"
        "Run `.venv/bin/python run_challenge.py` to execute and rebuild the submission.\n")
    relatives = [
        "02_treacherous_transpiler.ipynb", "submission.json", "team_instance.json",
        "requirements.txt", "START_HERE.md", "CHALLENGE_REPORT.txt", "CORE_PROGRESS.md",
        "run_challenge.py", "build_report.py", "breaq_ch2/__init__.py", "breaq_ch2/service.py",
    ]
    relatives += [str(path.relative_to(root)) for path in sorted(artifacts.iterdir())
                  if path.is_file() and path.name != "artifact_manifest.json"]
    manifest = {relative: hashlib.sha256((root / relative).read_bytes()).hexdigest() for relative in relatives}
    (artifacts / "artifact_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    relatives.append("submission_artifacts/artifact_manifest.json")
    archive_path = root / "BreaQ_CH2_submission.zip"
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for relative in relatives:
            archive.write(root / relative, arcname=relative)
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(relatives)
        for relative, expected in manifest.items():
            assert hashlib.sha256(archive.read(relative)).hexdigest() == expected
    print(f"Wrote {report.name} ({len(lines)} report lines).")
    print(f"Packaged and verified {len(relatives)} files in {archive_path.name}.")
    print(f"Defense: TP={defense['TP']}, FN={defense['FN']}, TN={defense['TN']}, FP={defense['FP']}; "
          f"{defense['validation_rejections']} invalid pairs rejected.")


if __name__ == "__main__":
    main()
