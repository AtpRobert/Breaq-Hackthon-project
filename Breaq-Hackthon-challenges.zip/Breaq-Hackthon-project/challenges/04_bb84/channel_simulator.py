"""Educational BB84 Alice/channel simulator.

This is a classical simulation of BB84 state preparation and measurement, not
real quantum communication or a complete security proof. It assumes an
authenticated public channel for basis announcements and protocol messages.
Basis 0 represents Z and basis 1 represents X. Measuring in the preparation
basis returns the prepared bit; measuring in the other basis returns a fresh
fair random bit. Eve independently intercepts each signal with probability
``eve_fraction``, measures in a random basis, and resends that measured state.
With zero noise, intercept-resend on fraction ``f`` yields approximately
``f/4`` errors among sifted bits.
The independent NumPy RNG streams are seeded for reproducible experiments,
not production cryptography. Python object privacy is only a modeling
convention: it is not a security boundary, and Bob's algorithm must use only
the documented interface. In particular, ``final_key`` is runner-only and
must not be made available to Bob.

Bob's measurement result is flipped after measurement with ``noise_rate``;
this is a simplified classical measurement-error model, not a physical noise
channel.

Run the self-test with::

    python channel_simulator.py --self-test

The simulator requires NumPy. Install it with ``python -m pip install numpy``.
"""

from __future__ import annotations

import argparse
from copy import deepcopy
from typing import Any, Sequence

import numpy as np


def _as_bits(values: Sequence[int] | np.ndarray, name: str) -> np.ndarray:
	"""Validate a one-dimensional array of binary integer values."""
	array = np.asarray(values)
	if array.ndim != 1:
		raise ValueError(f"{name} must be a one-dimensional bit array")
	if array.size == 0:
		return np.empty(0, dtype=np.uint8)
	if array.dtype.kind not in "biu" or not np.isin(array, (0, 1)).all():
		raise ValueError(f"{name} must contain only integer 0 or 1 values")
	return array.astype(np.uint8, copy=True)


def _as_indices(indices: Sequence[int] | np.ndarray, limit: int, name: str) -> np.ndarray:
	"""Validate unique, in-range, one-dimensional integer indices."""
	array = np.asarray(indices)
	if array.ndim != 1:
		raise ValueError(f"{name} must be one-dimensional")
	if array.size == 0:
		return np.empty(0, dtype=np.int64)
	if array.dtype.kind not in "iu":
		raise ValueError(f"{name} must contain integers")
	array = array.astype(np.int64, copy=True)
	if np.any(array < 0) or np.any(array >= limit):
		raise ValueError(f"{name} contains an out-of-range index")
	if np.unique(array).size != array.size:
		raise ValueError(f"{name} must not contain repeated indices")
	return array


def _validate_nonnegative_integer(value: int, name: str) -> None:
	if not isinstance(value, (int, np.integer)) or isinstance(value, (bool, np.bool_)):
		raise TypeError(f"{name} must be an integer")
	if value < 0:
		raise ValueError(f"{name} must be non-negative")


def toeplitz_hash_reference(
	bits: Sequence[int] | np.ndarray,
	seed_bits: Sequence[int] | np.ndarray,
	output_length: int,
) -> np.ndarray:
	"""Straightforward O(n*l) reference for the Toeplitz binary hash."""
	input_bits = _as_bits(bits, "bits")
	seed = _as_bits(seed_bits, "seed_bits")
	_validate_nonnegative_integer(output_length, "output_length")
	input_length = input_bits.size
	if input_length == 0 and output_length == 0:
		required_seed_length = 0
	else:
		required_seed_length = input_length + int(output_length) - 1
	if seed.size != required_seed_length:
		raise ValueError(
			f"seed_bits must contain exactly {required_seed_length} bits "
			f"for input length {input_length} and output length {output_length}"
		)

	result = np.zeros(int(output_length), dtype=np.uint8)
	for output_index in range(int(output_length)):
		parity = 0
		for input_index, bit in enumerate(input_bits):
			parity ^= int(bit) & int(seed[input_length - 1 + output_index - input_index])
		result[output_index] = parity
	return result


def toeplitz_hash(
	bits: Sequence[int] | np.ndarray,
	seed_bits: Sequence[int] | np.ndarray,
	output_length: int,
) -> np.ndarray:
	"""Hash bits with a Toeplitz matrix using FFT convolution, without a dense matrix.

	For ``n`` input and ``l`` output bits, exactly ``n + l - 1`` seed bits are
	required. The Toeplitz product is the convolution of ``bits`` and the seed;
	output ``i`` is coefficient ``n - 1 + i`` modulo two. Floating FFT
	coefficients are rounded to their nearest integer, then reduced modulo two.
	An error guard rejects results too far from integers; self-tests compare this
	implementation against the exact reference on random small inputs.

	Empty input produces all-zero output (after validating the specified seed
	length); zero output length returns an empty array. The fully empty case
	(input and output both length zero) accepts an empty seed.
	"""
	input_bits = _as_bits(bits, "bits")
	seed = _as_bits(seed_bits, "seed_bits")
	_validate_nonnegative_integer(output_length, "output_length")
	input_length = input_bits.size
	if input_length == 0 and output_length == 0:
		required_seed_length = 0
	else:
		required_seed_length = input_length + int(output_length) - 1
	if seed.size != required_seed_length:
		raise ValueError(
			f"seed_bits must contain exactly {required_seed_length} bits "
			f"for input length {input_length} and output length {output_length}"
		)
	if output_length == 0:
		return np.empty(0, dtype=np.uint8)
	if input_length == 0:
		return np.zeros(int(output_length), dtype=np.uint8)

	convolution_length = input_length + seed.size - 1
	fft_length = 1 << (convolution_length - 1).bit_length()
	coefficients = np.fft.irfft(
		np.fft.rfft(input_bits, fft_length) * np.fft.rfft(seed, fft_length),
		n=fft_length,
	)[:convolution_length]
	nearest_integers = np.rint(coefficients)
	if np.max(np.abs(coefficients - nearest_integers)) > 0.25:
		raise ArithmeticError("FFT convolution was not sufficiently close to integer coefficients")
	selected = nearest_integers[input_length - 1:input_length - 1 + int(output_length)]
	return np.remainder(selected.astype(np.int64), 2).astype(np.uint8)


class AliceSession:
	"""Alice and channel state for one finite BB84 experiment session.

	Alice's private bits and bases are sampled independently. The simulated
	channel optionally performs independent intercept-resend attacks. ``transmit``
	accepts Bob's chosen bases and returns Bob's results; Alice's bases are made
	public only by calling ``reveal_bases`` after transmission.
	"""

	def __init__(self, n_signals: int, noise_rate: float, eve_fraction: float, seed: int | None) -> None:
		if not isinstance(n_signals, (int, np.integer)) or isinstance(n_signals, (bool, np.bool_)):
			raise TypeError("n_signals must be an integer")
		if n_signals <= 0:
			raise ValueError("n_signals must be greater than zero")
		self._validate_probability(noise_rate, "noise_rate")
		self._validate_probability(eve_fraction, "eve_fraction")
		if seed is not None and (
			not isinstance(seed, (int, np.integer))
			or isinstance(seed, (bool, np.bool_))
			or seed < 0
		):
			raise ValueError("seed must be a non-negative integer or None")

		self.n_signals = int(n_signals)
		self.noise_rate = float(noise_rate)
		self.eve_fraction = float(eve_fraction)
		alice_seed, eve_seed, measurement_seed, noise_seed, public_seed = np.random.SeedSequence(seed).spawn(5)
		self._alice_rng = np.random.default_rng(alice_seed)
		self._eve_rng = np.random.default_rng(eve_seed)
		self._measurement_rng = np.random.default_rng(measurement_seed)
		self._noise_rng = np.random.default_rng(noise_seed)
		self._public_rng = np.random.default_rng(public_seed)

		self._alice_bits = self._alice_rng.integers(0, 2, size=self.n_signals, dtype=np.uint8)
		self._alice_bases = self._alice_rng.integers(0, 2, size=self.n_signals, dtype=np.uint8)
		self._bob_bases: np.ndarray | None = None
		self._bob_results: np.ndarray | None = None
		self._sifted_indices: np.ndarray | None = None
		self._key: np.ndarray | None = None
		self._pending_sample_positions: np.ndarray | None = None
		self._transmitted = False
		self._bases_revealed = False
		self._sample_removed = False
		self.parity_leak_bits = 0
		self.verification_leak_bits = 0
		self._public_transcript: list[dict[str, Any]] = []

	@staticmethod
	def _validate_probability(value: float, name: str) -> None:
		if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, float, np.integer, np.floating)):
			raise TypeError(f"{name} must be a number between 0 and 1")
		if not np.isfinite(value) or not 0.0 <= float(value) <= 1.0:
			raise ValueError(f"{name} must be between 0 and 1 inclusive")

	@property
	def public_transcript(self) -> list[dict[str, Any]]:
		"""Return a copy of public protocol messages, never private state."""
		return deepcopy(self._public_transcript)

	def _require_transmitted(self) -> None:
		if not self._transmitted:
			raise RuntimeError("transmit() must be called first")

	def _require_key_ready(self) -> np.ndarray:
		if self._key is None or not self._sample_removed or self._pending_sample_positions is not None:
			raise RuntimeError("sift() and remove_sample() must complete before this operation")
		return self._key

	def transmit(self, bob_bases: Sequence[int] | np.ndarray) -> np.ndarray:
		"""Simulate channel transmission and Bob measurement exactly once."""
		if self._transmitted:
			raise RuntimeError("transmit() may be called only once")
		bases = _as_bits(bob_bases, "bob_bases")
		if bases.size != self.n_signals:
			raise ValueError(f"bob_bases must contain exactly {self.n_signals} bits")

		alice_bases = self._alice_bases
		alice_bits = self._alice_bits
		bob_measurement_random = self._measurement_rng.integers(0, 2, size=self.n_signals, dtype=np.uint8)
		direct_results = np.where(bases == alice_bases, alice_bits, bob_measurement_random)

		intercepted = self._eve_rng.random(self.n_signals) < self.eve_fraction
		eve_bases = self._eve_rng.integers(0, 2, size=self.n_signals, dtype=np.uint8)
		eve_measurement_random = self._measurement_rng.integers(0, 2, size=self.n_signals, dtype=np.uint8)
		eve_results = np.where(eve_bases == alice_bases, alice_bits, eve_measurement_random)
		bob_after_resend_random = self._measurement_rng.integers(0, 2, size=self.n_signals, dtype=np.uint8)
		resend_results = np.where(eve_bases == bases, eve_results, bob_after_resend_random)

		results = np.where(intercepted, resend_results, direct_results).astype(np.uint8)
		noise_flips = self._noise_rng.random(self.n_signals) < self.noise_rate
		results ^= noise_flips.astype(np.uint8)
		self._bob_bases = bases
		self._bob_results = results
		self._transmitted = True
		return results.copy()

	def reveal_bases(self) -> np.ndarray:
		"""Publish and return a copy of Alice's bases after transmission."""
		self._require_transmitted()
		self._bases_revealed = True
		self._public_transcript.append({
			"type": "alice_bases_revealed",
			"bases": self._alice_bases.astype(int).tolist(),
		})
		return self._alice_bases.copy()

	def sift(self, kept_indices: Sequence[int] | np.ndarray) -> None:
		"""Accept only the exact ordered positions where Alice and Bob bases match."""
		self._require_transmitted()
		if not self._bases_revealed:
			raise RuntimeError("reveal_bases() must be called before sift()")
		if self._sifted_indices is not None:
			raise RuntimeError("sift() may be called only once")
		indices = _as_indices(kept_indices, self.n_signals, "kept_indices")
		expected = np.flatnonzero(self._alice_bases == self._bob_bases)
		if not np.array_equal(indices, expected):
			raise ValueError("kept_indices must exactly match matching-basis positions in ascending order")
		self._sifted_indices = indices.copy()
		self._key = self._alice_bits[indices].copy()
		self._public_transcript.append({
			"type": "sifted_positions",
			"indices": indices.tolist(),
		})

	def disclose_sample(self, k: int) -> tuple[np.ndarray, np.ndarray]:
		"""Uniformly reveal k distinct sifted-key positions and their Alice bits."""
		if self._key is None:
			raise RuntimeError("sift() must be called before disclose_sample()")
		if self._pending_sample_positions is not None:
			raise RuntimeError("remove_sample() must follow the previous sample disclosure")
		_validate_nonnegative_integer(k, "k")
		if k >= self._key.size:
			raise ValueError("sample size must leave at least one key bit")
		positions = np.sort(self._public_rng.choice(self._key.size, size=int(k), replace=False)).astype(np.int64)
		sample_bits = self._key[positions].copy()
		self._pending_sample_positions = positions
		self._public_transcript.append({
			"type": "sample_bits_disclosed",
			"positions": positions.tolist(),
			"bits": sample_bits.astype(int).tolist(),
		})
		return positions.copy(), sample_bits

	def remove_sample(self) -> None:
		"""Remove the last disclosed sample from Alice's key, preserving order."""
		if self._key is None or self._pending_sample_positions is None:
			raise RuntimeError("disclose_sample() must be called before remove_sample()")
		keep_mask = np.ones(self._key.size, dtype=bool)
		keep_mask[self._pending_sample_positions] = False
		self._key = self._key[keep_mask].copy()
		self._pending_sample_positions = None
		self._sample_removed = True
		self._public_transcript.append({"type": "sample_positions_removed"})

	def parity(self, indices: Sequence[int] | np.ndarray) -> int:
		"""Reveal XOR of selected remaining-key bits and account for every reply."""
		key = self._require_key_ready()
		selected = _as_indices(indices, key.size, "indices")
		parity_bit = int(np.bitwise_xor.reduce(key[selected], initial=np.uint8(0)))
		self.parity_leak_bits += 1
		self._public_transcript.append({
			"type": "parity_reply",
			"indices": selected.tolist(),
			"bit": parity_bit,
		})
		return parity_bit

	def public_permutation(self) -> np.ndarray:
		"""Return and publish a random permutation of current-key indices."""
		key = self._require_key_ready()
		permutation = self._public_rng.permutation(key.size).astype(np.int64)
		self._public_transcript.append({
			"type": "public_key_permutation",
			"indices": permutation.tolist(),
		})
		return permutation.copy()

	def verification_tag(
		self,
		seed_bits: Sequence[int] | np.ndarray,
		tag_length: int,
	) -> np.ndarray:
		"""Publish a Toeplitz verification tag and count its full bit length as leakage."""
		key = self._require_key_ready()
		_validate_nonnegative_integer(tag_length, "tag_length")
		tag = toeplitz_hash(key, seed_bits, int(tag_length))
		self.verification_leak_bits += int(tag_length)
		self._public_transcript.append({
			"type": "verification_tag",
			"bits": tag.astype(int).tolist(),
		})
		return tag.copy()

	def final_key(
		self,
		seed_bits: Sequence[int] | np.ndarray,
		output_length: int,
	) -> np.ndarray:
		"""Runner-only privacy-amplification result; never expose this to Bob."""
		key = self._require_key_ready()
		_validate_nonnegative_integer(output_length, "output_length")
		if output_length > key.size:
			raise ValueError("output_length cannot exceed the remaining key length")
		return toeplitz_hash(key, seed_bits, int(output_length))


def _self_test() -> None:
	"""Check BB84 basis behavior and optimized Toeplitz hashing."""
	matching = AliceSession(n_signals=256, noise_rate=0.0, eve_fraction=0.0, seed=101)
	matching_bases = matching._alice_bases.copy()
	matching_results = matching.transmit(matching_bases)
	assert np.array_equal(matching_results, matching._alice_bits)

	opposite = AliceSession(n_signals=8192, noise_rate=0.0, eve_fraction=0.0, seed=202)
	opposite_bases = 1 - opposite._alice_bases
	opposite_results = opposite.transmit(opposite_bases)
	opposite_error_fraction = float(np.mean(opposite_results != opposite._alice_bits))
	assert 0.47 < opposite_error_fraction < 0.53, opposite_error_fraction

	eavesdropped = AliceSession(n_signals=8192, noise_rate=0.0, eve_fraction=1.0, seed=404)
	matching_bases = eavesdropped._alice_bases.copy()
	eavesdropped_results = eavesdropped.transmit(matching_bases)
	eavesdrop_error_fraction = float(np.mean(eavesdropped_results != eavesdropped._alice_bits))
	assert 0.22 < eavesdrop_error_fraction < 0.28, eavesdrop_error_fraction

	rng = np.random.default_rng(303)
	for input_length in range(0, 18):
		for output_length in range(0, 18):
			if input_length == 0 and output_length == 0:
				seed_length = 0
			else:
				seed_length = input_length + output_length - 1
			bits = rng.integers(0, 2, size=input_length, dtype=np.uint8)
			seed_bits = rng.integers(0, 2, size=seed_length, dtype=np.uint8)
			assert np.array_equal(
				toeplitz_hash(bits, seed_bits, output_length),
				toeplitz_hash_reference(bits, seed_bits, output_length),
			)

	print(
		"Self-test passed: matching/opposite bases, intercept-resend error rate, "
		"and Toeplitz implementations agree."
	)


def main() -> None:
	parser = argparse.ArgumentParser(description="Run the educational BB84 channel simulator self-test.")
	parser.add_argument("--self-test", action="store_true", help="run deterministic simulator/hash checks")
	args = parser.parse_args()
	if args.self_test:
		_self_test()
	else:
		parser.print_help()


if __name__ == "__main__":
	main()
