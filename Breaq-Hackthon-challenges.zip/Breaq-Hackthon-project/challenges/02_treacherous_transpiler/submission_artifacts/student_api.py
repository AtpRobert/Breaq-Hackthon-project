"""Independent numerical verification for the bounded Challenge 2 contract.

Only verify_compilation is public. No compiler service, notebook, case labels,
metadata, trace names, or trigger conditions are used as verification evidence.
"""
import math as _math
from numbers import Real as _Real

import numpy as _np
from qiskit import QuantumCircuit as _QuantumCircuit
from qiskit.circuit import Barrier as _Barrier
from qiskit.circuit.library import (
    IGate as _I, HGate as _H, XGate as _X, YGate as _Y, ZGate as _Z,
    SGate as _S, SdgGate as _Sdg, TGate as _T, TdgGate as _Tdg,
    SXGate as _SX, SXdgGate as _SXdg, RXGate as _RX, RYGate as _RY,
    RZGate as _RZ, PhaseGate as _P, CXGate as _CX, CZGate as _CZ,
    SwapGate as _Swap,
)
from qiskit.quantum_info import Operator as _Operator

__all__ = ["verify_compilation"]
_ATOL = 1e-9
_RTOL = 1e-9
_GATES = {
    "id": (_I, 1, 0), "h": (_H, 1, 0), "x": (_X, 1, 0),
    "y": (_Y, 1, 0), "z": (_Z, 1, 0), "s": (_S, 1, 0),
    "sdg": (_Sdg, 1, 0), "t": (_T, 1, 0), "tdg": (_Tdg, 1, 0),
    "sx": (_SX, 1, 0), "sxdg": (_SXdg, 1, 0),
    "rx": (_RX, 1, 1), "ry": (_RY, 1, 1), "rz": (_RZ, 1, 1),
    "p": (_P, 1, 1), "cx": (_CX, 2, 0), "cz": (_CZ, 2, 0),
    "swap": (_Swap, 2, 0),
}


def _valid(circuit):
    if not isinstance(circuit, _QuantumCircuit):
        return False
    if not 1 <= circuit.num_qubits <= 6 or circuit.num_clbits or circuit.num_ancillas:
        return False
    if circuit.parameters or circuit.layout is not None or len(circuit.data) > 500:
        return False
    if not _math.isfinite(float(circuit.global_phase)):
        return False
    for instruction in circuit.data:
        op = instruction.operation
        if instruction.clbits or op.num_clbits:
            return False
        if op.name == "barrier":
            if op.base_class is not _Barrier or op.params:
                return False
            if not 1 <= op.num_qubits <= circuit.num_qubits:
                return False
        else:
            specification = _GATES.get(op.name)
            if specification is None:
                return False
            gate_type, width, parameter_count = specification
            # A custom gate called 'x' is not the standard X gate.
            if op.base_class is not gate_type or op.num_qubits != width:
                return False
            if len(op.params) != parameter_count:
                return False
            # Open-control CX/CZ variants are outside the permitted gate set.
            if hasattr(op, "ctrl_state") and op.ctrl_state != 1:
                return False
        if len(instruction.qubits) != op.num_qubits:
            return False
        if len(set(instruction.qubits)) != len(instruction.qubits):
            return False
        for value in op.params:
            if not isinstance(value, _Real) or not _math.isfinite(float(value)):
                return False
    return True


def verify_compilation(source, candidate) -> bool:
    """Accept only supported equivalent circuits, allowing one global phase.

    Fail closed on unsupported data, numerical failures or validation errors.
    This constructs full matrices, so the explicit six-qubit bound is essential.
    It is numerical translation validation, not a formal equivalence proof.
    """
    try:
        if not _valid(source) or not _valid(candidate):
            return False
        if source.num_qubits != candidate.num_qubits:
            return False
        u = _np.asarray(_Operator(source).data, dtype=complex)
        v = _np.asarray(_Operator(candidate).data, dtype=complex)
        if not _np.isfinite(u).all() or not _np.isfinite(v).all():
            return False
        identity = _np.eye(u.shape[0], dtype=complex)
        if not _np.allclose(u.conj().T @ u, identity, atol=_ATOL, rtol=_RTOL):
            return False
        if not _np.allclose(v.conj().T @ v, identity, atol=_ATOL, rtol=_RTOL):
            return False
        overlap = _np.vdot(u, v)
        if not _np.isfinite(overlap) or abs(overlap) < _ATOL:
            return False
        phase = overlap / abs(overlap)
        return bool(_np.allclose(v, phase * u, atol=_ATOL, rtol=_RTOL))
    except Exception:
        return False
