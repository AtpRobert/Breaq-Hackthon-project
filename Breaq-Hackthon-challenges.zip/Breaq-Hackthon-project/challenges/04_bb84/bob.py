"""Bob's educational BB84 processing logic.

The public channel is assumed to be authenticated. The parameter-estimation
Hoeffding bound and privacy-amplification length below are simplified
challenge formulas, not a complete finite-key or composable security proof for
arbitrary quantum attacks. Observed errors are treated conservatively and do
not identify whether Eve or ordinary noise caused them. A successful result is
therefore labeled "key established under the challenge model", never as a
production-secure key.

Bob uses only AliceSession's public methods and leakage counters. Python object
privacy is a modeling convention, not a security boundary; the experiment
runner must keep AliceSession.final_key unavailable to Bob's algorithm.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from math import floor, log, log2, sqrt
from time import perf_counter
from typing import Any

import numpy as np

from channel_simulator import AliceSession, toeplitz_hash


@dataclass
class BobConfig:
	"""Protocol settings for the educational challenge model.

	The challenge PDF's ``10^10`` parameter-estimation value appears to be a
	missing-minus-sign typo; this implementation defaults to epsilon_PE=10^-10.
	"""

	epsilon_pe: float = 1e-10
	epsilon_pa: float = 1e-10
	verification_tag_length: int = 64
	max_verification_attempts: int = 3
	max_parity_queries: int = 100_000
	max_corrections: int = 10_000
	fallback_block_size: int = 16

	def __post_init__(self) -> None:
		for name, value in (("epsilon_pe", self.epsilon_pe), ("epsilon_pa", self.epsilon_pa)):
			if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 < value < 1:
				raise ValueError(f"{name} must be between 0 and 1, exclusive")
		for name in ("verification_tag_length", "max_verification_attempts", "max_parity_queries", "max_corrections", "fallback_block_size"):
			value = getattr(self, name)
			if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
				raise ValueError(f"{name} must be a positive integer")
		if self.max_verification_attempts > 3:
			raise ValueError("max_verification_attempts cannot exceed three")


@dataclass
class BobResult:
	"""Outcome and accounting for one execution of Bob's protocol."""

	status: str
	abort_reason: str | None
	sifted_length: int
	sample_size: int
	sample_errors: int | None
	q_hat: float | None
	q_upper: float | None
	remaining_length: int
	parity_leak_bits: int
	verification_leak_bits: int
	final_length: int
	final_key: np.ndarray | None
	privacy_seed: np.ndarray | None
	timings: dict[str, float] = field(default_factory=dict)
	verification_attempts: int = 0
	verification_collision_bound: float | None = None
	error_corrections: int = 0


class _CascadeLimitExceeded(RuntimeError):
	pass


def binary_entropy(probability: float) -> float:
	"""Return binary entropy in bits, including exact endpoint values."""
	if not 0.0 <= probability <= 1.0:
		raise ValueError("probability must be between 0 and 1 inclusive")
	if probability in (0.0, 1.0):
		return 0.0
	return -probability * log2(probability) - (1.0 - probability) * log2(1.0 - probability)


def _validate_run_inputs(
	n_signals: int,
	sample_size: int,
	seed: int,
	config: BobConfig,
) -> None:
	for name, value in (("n_signals", n_signals), ("sample_size", sample_size), ("seed", seed)):
		if not isinstance(value, (int, np.integer)) or isinstance(value, (bool, np.bool_)):
			raise TypeError(f"{name} must be an integer")
	if n_signals <= 0:
		raise ValueError("n_signals must be greater than zero")
	if sample_size <= 0:
		raise ValueError("sample_size must be greater than zero")
	if seed < 0:
		raise ValueError("seed must be non-negative")
	if not isinstance(config, BobConfig):
		raise TypeError("config must be a BobConfig instance")


def _cascade_correct(
	session: AliceSession,
	bob_key: np.ndarray,
	q_hat: float,
	config: BobConfig,
	query_counter: list[int],
	correction_counter: list[int],
) -> None:
	"""Run four Cascade passes with canonical-key index views and look-back."""
	key_length = bob_key.size
	if key_length == 0:
		return
	if q_hat > 0.0:
		initial_block_size = max(1, min(key_length, int(round(0.73 / q_hat))))
	else:
		# Zero observed sample errors still permits unseen errors; use a modest,
		# documented fallback block size rather than dividing by zero.
		initial_block_size = min(key_length, config.fallback_block_size)

	pass_blocks: list[list[np.ndarray]] = []

	def alice_parity(indices: np.ndarray) -> int:
		if query_counter[0] >= config.max_parity_queries:
			raise _CascadeLimitExceeded("maximum parity-query limit reached")
		query_counter[0] += 1
		return session.parity(indices)

	def bob_parity(indices: np.ndarray) -> int:
		return int(np.bitwise_xor.reduce(bob_key[indices], initial=np.uint8(0)))

	def locate_error(indices: np.ndarray) -> int:
		"""Binary search using only public Alice parity replies."""
		view = indices
		while view.size > 1:
			middle = view.size // 2
			left = view[:middle]
			if alice_parity(left) != bob_parity(left):
				view = left
			else:
				view = view[middle:]
		return int(view[0])

	for pass_index in range(4):
		block_size = min(key_length, initial_block_size * (2 ** pass_index))
		permutation = session.public_permutation()
		blocks = [permutation[start:start + block_size] for start in range(0, key_length, block_size)]
		pass_blocks.append(blocks)
		work_queue: deque[tuple[int, int]] = deque(
			(pass_index, block_index) for block_index in range(len(blocks))
		)
		queued = set(work_queue)

		while work_queue:
			current_pass, block_index = work_queue.popleft()
			queued.discard((current_pass, block_index))
			block = pass_blocks[current_pass][block_index]
			if alice_parity(block) == bob_parity(block):
				continue

			if correction_counter[0] >= config.max_corrections:
				raise _CascadeLimitExceeded("maximum error-correction limit reached")
			canonical_index = locate_error(block)
			bob_key[canonical_index] ^= np.uint8(1)
			correction_counter[0] += 1

			# A correction can invalidate a parity already checked in any earlier
			# pass. Revisit each affected block; permutations remain index views.
			affected = [(current_pass, block_index)]
			for earlier_pass in range(current_pass):
				for earlier_block_index, earlier_block in enumerate(pass_blocks[earlier_pass]):
					if np.any(earlier_block == canonical_index):
						affected.append((earlier_pass, earlier_block_index))
			for item in affected:
				if item not in queued:
					work_queue.append(item)
					queued.add(item)


def run_bob(
	session: AliceSession,
	n_signals: int,
	sample_size: int,
	seed: int,
	config: BobConfig,
) -> BobResult:
	"""Run Bob's BB84 protocol using only AliceSession's public interface."""
	_validate_run_inputs(n_signals, sample_size, seed, config)
	if not isinstance(session, AliceSession):
		raise TypeError("session must be an AliceSession")

	started = perf_counter()
	timings = {
		"measurement_sifting": 0.0,
		"parameter_estimation": 0.0,
		"error_correction": 0.0,
		"key_verification": 0.0,
		"privacy_amplification": 0.0,
		"total": 0.0,
	}
	sifted_length = 0
	actual_sample_size = int(sample_size)
	sample_errors: int | None = None
	q_hat: float | None = None
	q_upper: float | None = None
	remaining_length = 0
	final_key: np.ndarray | None = None
	privacy_seed: np.ndarray | None = None
	verification_attempts = 0
	verification_collision_bound: float | None = None
	error_corrections = 0

	def finish(abort_reason: str | None = None) -> BobResult:
		timings["total"] = perf_counter() - started
		return BobResult(
			status="key established under the challenge model" if abort_reason is None else "aborted",
			abort_reason=abort_reason,
			sifted_length=sifted_length,
			sample_size=actual_sample_size,
			sample_errors=sample_errors,
			q_hat=q_hat,
			q_upper=q_upper,
			remaining_length=remaining_length,
			parity_leak_bits=session.parity_leak_bits,
			verification_leak_bits=session.verification_leak_bits,
			final_length=0 if final_key is None else int(final_key.size),
			final_key=None if final_key is None else final_key.copy(),
			privacy_seed=None if privacy_seed is None else privacy_seed.copy(),
			timings=timings.copy(),
			verification_attempts=verification_attempts,
			verification_collision_bound=verification_collision_bound,
			error_corrections=error_corrections,
		)

	# 1. Bob's basis RNG persists for the duration of this run; the master seed
	# creates independent streams for bases and public Toeplitz seed material.
	measurement_started = perf_counter()
	basis_seed, public_seed = np.random.SeedSequence(int(seed)).spawn(2)
	basis_rng = np.random.default_rng(basis_seed)
	public_rng = np.random.default_rng(public_seed)
	bob_bases = basis_rng.integers(0, 2, size=int(n_signals), dtype=np.uint8)
	bob_measurements = session.transmit(bob_bases)
	alice_bases = session.reveal_bases()
	kept_indices = np.flatnonzero(bob_bases == alice_bases)
	bob_key = bob_measurements[kept_indices].copy()
	session.sift(kept_indices)
	sifted_length = int(kept_indices.size)
	timings["measurement_sifting"] = perf_counter() - measurement_started

	# A nonempty sample and at least one retained bit are required by the
	# requested sample-sampling API and subsequent finite-key expression.
	if sifted_length <= sample_size:
		return finish(
			f"insufficient sifted bits: need more than {sample_size}, got {sifted_length}"
		)

	# 2. Parameter estimation. Sample data are disclosed and removed, so are not
	# subtracted again as error-correction leakage.
	pe_started = perf_counter()
	sample_positions, alice_sample_bits = session.disclose_sample(int(sample_size))
	sample_errors = int(np.count_nonzero(bob_key[sample_positions] != alice_sample_bits))
	q_hat = sample_errors / int(sample_size)
	keep_mask = np.ones(bob_key.size, dtype=bool)
	keep_mask[sample_positions] = False
	bob_key = bob_key[keep_mask].copy()
	session.remove_sample()
	remaining_length = int(bob_key.size)
	q_upper = min(1.0, q_hat + sqrt(log(1.0 / config.epsilon_pe) / (2.0 * int(sample_size))))
	timings["parameter_estimation"] = perf_counter() - pe_started
	if q_upper >= 0.11:
		return finish(f"parameter-estimation upper bound {q_upper:.6f} is at least 0.11")

	# 3. Four-pass Cascade, plus another bounded correction round after each
	# failed verification attempt. Every Alice parity comes from session.parity.
	ec_started = perf_counter()
	query_counter = [0]
	correction_counter = [0]
	try:
		_cascade_correct(session, bob_key, q_hat, config, query_counter, correction_counter)
	except _CascadeLimitExceeded as error:
		error_corrections = correction_counter[0]
		timings["error_correction"] = perf_counter() - ec_started
		return finish(str(error))
	error_corrections = correction_counter[0]
	timings["error_correction"] = perf_counter() - ec_started

	# 4. Use a fresh public Toeplitz seed for each verification attempt. The
	# cumulative collision bound is at most attempts * 2^-tag_length by a union
	# bound; this is not a certainty guarantee.
	verification_started = perf_counter()
	verified = False
	for attempt in range(1, config.max_verification_attempts + 1):
		if attempt > 1:
			try:
				_cascade_correct(session, bob_key, q_hat, config, query_counter, correction_counter)
			except _CascadeLimitExceeded as error:
				error_corrections = correction_counter[0]
				verification_attempts = attempt - 1
				verification_collision_bound = min(
					1.0, verification_attempts * 2.0 ** (-config.verification_tag_length)
				)
				timings["key_verification"] = perf_counter() - verification_started
				return finish(f"additional Cascade correction stopped: {error}")
			error_corrections = correction_counter[0]

		verification_seed = public_rng.integers(
			0, 2, size=bob_key.size + config.verification_tag_length - 1, dtype=np.uint8
		)
		alice_tag = session.verification_tag(verification_seed, config.verification_tag_length)
		bob_tag = toeplitz_hash(bob_key, verification_seed, config.verification_tag_length)
		verification_attempts = attempt
		verification_collision_bound = min(
			1.0, attempt * 2.0 ** (-config.verification_tag_length)
		)
		if np.array_equal(alice_tag, bob_tag):
			verified = True
			break
	timings["key_verification"] = perf_counter() - verification_started
	if not verified:
		return finish(
			f"key verification failed after {verification_attempts} attempts; "
			"additional correction did not reconcile the keys"
		)

	# 5. Challenge-model privacy amplification. n is specifically the key length
	# after sample removal. Never reuse a verification seed for this hash.
	pa_started = perf_counter()
	n = int(bob_key.size)
	leakage = session.parity_leak_bits + session.verification_leak_bits
	privacy_length = floor(
		n * (1.0 - binary_entropy(q_upper))
		- leakage
		- 2.0 * log2(1.0 / config.epsilon_pa)
	)
	if privacy_length <= 0:
		timings["privacy_amplification"] = perf_counter() - pa_started
		return finish("privacy-amplification length is non-positive after leakage and security penalties")
	privacy_seed = public_rng.integers(
		0, 2, size=n + privacy_length - 1, dtype=np.uint8
	)
	final_key = toeplitz_hash(bob_key, privacy_seed, privacy_length)
	timings["privacy_amplification"] = perf_counter() - pa_started
	return finish()
