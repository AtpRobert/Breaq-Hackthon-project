"""CLI runner for reproducible educational BB84 simulation experiments.

The simulation assumes an authenticated public channel. Eve's fraction is the
fraction of transmissions intercepted, not QBER. For intercept-resend, the
expected sifted QBER is f/4 without noise; with independent output-flip noise
e it is e + f/4 - 2*e*(f/4). Small interception fractions need not trigger an
abort because privacy amplification is intended to account for bounded
information exposure in the challenge model.

This is not real quantum communication or a complete security proof. Published
simulation seeds make these deterministic experiments predictable and are
not suitable for production cryptography. Private keys are never written by
default. Message mode is a simulated one-time pad and provides no message
authentication.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from dataclasses import asdict
from pathlib import Path
from time import perf_counter
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import bob as bob_module
import channel_simulator as channel_module
from bob import BobConfig, BobResult, run_bob
from channel_simulator import AliceSession, toeplitz_hash, toeplitz_hash_reference


SUITE = [
	{"name": "no_eve_no_noise", "noise_rate": 0.0, "eve_fraction": 0.0},
	{"name": "no_eve_noise_1pct", "noise_rate": 0.01, "eve_fraction": 0.0},
	{"name": "no_eve_noise_2pct", "noise_rate": 0.02, "eve_fraction": 0.0},
	{"name": "no_eve_noise_4pct", "noise_rate": 0.04, "eve_fraction": 0.0},
	{"name": "eve_1pct_no_noise", "noise_rate": 0.0, "eve_fraction": 0.01},
	{"name": "eve_25pct_no_noise", "noise_rate": 0.0, "eve_fraction": 0.25},
	{"name": "eve_100pct_no_noise", "noise_rate": 0.0, "eve_fraction": 1.0},
]


def _positive_int(value: str) -> int:
	try:
		parsed = int(value)
	except ValueError as error:
		raise argparse.ArgumentTypeError("must be an integer") from error
	if parsed <= 0:
		raise argparse.ArgumentTypeError("must be greater than zero")
	return parsed


def _probability(value: str) -> float:
	try:
		parsed = float(value)
	except ValueError as error:
		raise argparse.ArgumentTypeError("must be a number between 0 and 1") from error
	if not 0.0 <= parsed <= 1.0:
		raise argparse.ArgumentTypeError("must be between 0 and 1 inclusive")
	return parsed


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
	parser = argparse.ArgumentParser(description="Run educational BB84 simulation trials.")
	parser.add_argument("--signals", type=_positive_int, default=200_000)
	parser.add_argument("--sample-size", type=_positive_int, default=20_000)
	parser.add_argument("--noise-rate", type=_probability, default=0.02)
	parser.add_argument("--eve-fraction", type=_probability, default=0.0)
	parser.add_argument("--seed", type=int, default=42)
	parser.add_argument("--trials", type=_positive_int, default=1)
	parser.add_argument("--output-dir", type=Path, default=Path("bb84_results"))
	parser.add_argument("--message", help="optional short UTF-8 message for an OTP demonstration")
	parser.add_argument("--suite", action="store_true", help="run the predefined scenario suite")
	parser.add_argument("--self-test", action="store_true", help="run simulator and runner self-tests")
	args = parser.parse_args(argv)
	if args.seed < 0:
		parser.error("--seed must be non-negative")
	if args.sample_size >= args.signals:
		parser.error("--sample-size must be smaller than --signals")
	return args


def _derive_seeds(master_seed: int, count: int) -> list[dict[str, int]]:
	"""Derive unique Alice/Bob child seeds for every scenario/trial pair."""
	children = np.random.SeedSequence(master_seed).spawn(2 * count)
	seed_rows: list[dict[str, int]] = []
	used: set[int] = set()
	for index in range(count):
		alice_seed = int(children[2 * index].generate_state(2, dtype=np.uint32).dot(
		np.array([1, 1 << 32], dtype=np.uint64)
	))
		bob_seed = int(children[2 * index + 1].generate_state(2, dtype=np.uint32).dot(
		np.array([1, 1 << 32], dtype=np.uint64)
	))
		if alice_seed in used or bob_seed in used or alice_seed == bob_seed:
			raise RuntimeError("SeedSequence produced a duplicate child seed")
		used.update((alice_seed, bob_seed))
		seed_rows.append({"alice_seed": alice_seed, "bob_seed": bob_seed})
	return seed_rows


def _message_demo(message: str, alice_key: np.ndarray, bob_key: np.ndarray) -> dict[str, Any]:
	"""Demonstrate OTP encryption with fresh key bits, without authenticating."""
	message_bytes = message.encode("utf-8")
	message_bits = np.unpackbits(np.frombuffer(message_bytes, dtype=np.uint8), bitorder="big")
	if alice_key.size < message_bits.size or bob_key.size < message_bits.size:
		raise ValueError(
			f"OTP demo refused: message needs {message_bits.size} key bits, "
			f"but only {min(alice_key.size, bob_key.size)} are available"
		)

	# The prefix is reserved for this demonstration and is never consumed elsewhere.
	alice_pad = alice_key[:message_bits.size]
	bob_pad = bob_key[:message_bits.size]
	ciphertext = np.bitwise_xor(message_bits, bob_pad)
	decrypted_bits = np.bitwise_xor(ciphertext, alice_pad)
	decrypted_bytes = np.packbits(decrypted_bits, bitorder="big").tobytes()
	return {
		"status": "completed" if decrypted_bytes == message_bytes else "correctness_failure",
		"key_bits_used": int(message_bits.size),
		"roundtrip_ok": decrypted_bytes == message_bytes,
		"ciphertext_hex": ciphertext.tobytes().hex(),
		"authentication": "not provided",
	}


def _transcript_path(output_dir: Path, scenario_name: str, trial_number: int) -> Path:
	transcript_dir = output_dir / "public_transcripts"
	transcript_dir.mkdir(parents=True, exist_ok=True)
	return transcript_dir / f"{scenario_name}_trial_{trial_number:03d}.json"


def _run_trial(
	scenario: dict[str, Any],
	trial_number: int,
	args: argparse.Namespace,
	seeds: dict[str, int],
	output_dir: Path,
) -> tuple[dict[str, Any], dict[str, Any]]:
	trial_started = perf_counter()
	session = AliceSession(
		n_signals=args.signals,
		noise_rate=scenario["noise_rate"],
		eve_fraction=scenario["eve_fraction"],
		seed=seeds["alice_seed"],
	)
	bob_config = BobConfig()
	bob_result: BobResult = run_bob(
		session=session,
		n_signals=args.signals,
		sample_size=args.sample_size,
		seed=seeds["bob_seed"],
		config=bob_config,
	)

	correctness_agreement: bool | None = None
	message_result: dict[str, Any] | None = None
	status = bob_result.status
	abort_reason = bob_result.abort_reason
	if bob_result.final_key is not None and bob_result.privacy_seed is not None:
		# Evaluator-only check: never passed into Bob or his correction logic.
		alice_final_key = session.final_key(bob_result.privacy_seed, bob_result.final_length)
		correctness_agreement = bool(np.array_equal(alice_final_key, bob_result.final_key))
		if not correctness_agreement:
			status = "correctness_failure"
			abort_reason = "evaluator-only Alice/Bob final-key comparison failed"
		elif args.message is not None:
			try:
				message_result = _message_demo(args.message, alice_final_key, bob_result.final_key)
			except ValueError as error:
				message_result = {
					"status": "refused_key_too_short",
					"reason": str(error),
					"key_bits_used": 0,
					"roundtrip_ok": False,
					"authentication": "not provided",
				}

	trial_runtime = perf_counter() - trial_started
	row = {
		"scenario": scenario["name"],
		"trial": trial_number,
		"signals": args.signals,
		"sample_size": bob_result.sample_size,
		"noise_rate": scenario["noise_rate"],
		"eve_fraction": scenario["eve_fraction"],
		"sifted_bits": bob_result.sifted_length,
		"sample_errors": bob_result.sample_errors,
		"q_hat": bob_result.q_hat,
		"q_upper": bob_result.q_upper,
		"remaining_bits": bob_result.remaining_length,
		"parity_leak_bits": bob_result.parity_leak_bits,
		"verification_leak_bits": bob_result.verification_leak_bits,
		"final_key_length": bob_result.final_length,
		"final_key_agreement": correctness_agreement,
		"verification_attempts": bob_result.verification_attempts,
		"verification_collision_bound": bob_result.verification_collision_bound,
		"error_corrections": bob_result.error_corrections,
		"status": status,
		"bob_status": bob_result.status,
		"abort_reason": abort_reason,
		"runtime_seconds": trial_runtime,
		"message_demo_status": None if message_result is None else message_result["status"],
		"message_key_bits_used": None if message_result is None else message_result["key_bits_used"],
		"message_roundtrip_ok": None if message_result is None else message_result["roundtrip_ok"],
		"message_ciphertext_hex": None if message_result is None else message_result.get("ciphertext_hex"),
	}

	transcript = {
		"scenario": scenario["name"],
		"trial": trial_number,
		"assumption": "authenticated public channel",
		"events": session.public_transcript,
		"note": "Disclosed sample bits and public parity/tag messages are included; private bits and simulation seeds are excluded.",
	}
	with _transcript_path(output_dir, scenario["name"], trial_number).open(
		"w", encoding="utf-8"
	) as transcript_file:
		json.dump(transcript, transcript_file, indent=2)
		transcript_file.write("\n")
	return row, message_result or {}


def _write_results(rows: list[dict[str, Any]], path: Path) -> None:
	if not rows:
		return
	with path.open("w", newline="", encoding="utf-8") as csv_file:
		writer = csv.DictWriter(csv_file, fieldnames=list(rows[0]))
		writer.writeheader()
		writer.writerows(rows)


def _aggregate(rows: list[dict[str, Any]]) -> dict[str, Any]:
	by_scenario: dict[str, list[dict[str, Any]]] = {}
	for row in rows:
		by_scenario.setdefault(row["scenario"], []).append(row)
	return {
		name: {
			"trials": len(scenario_rows),
			"aborted_trials": sum(row["status"] == "aborted" for row in scenario_rows),
			"abort_rate": sum(row["status"] == "aborted" for row in scenario_rows) / len(scenario_rows),
			"correctness_failures": sum(row["status"] == "correctness_failure" for row in scenario_rows),
			"mean_q_hat": _mean([row["q_hat"] for row in scenario_rows]),
			"mean_q_upper": _mean([row["q_upper"] for row in scenario_rows]),
			"mean_final_key_length": _mean([row["final_key_length"] for row in scenario_rows]),
		}
		for name, scenario_rows in by_scenario.items()
	}


def _mean(values: list[float | int | None]) -> float | None:
	valid = [float(value) for value in values if value is not None]
	return None if not valid else float(np.mean(valid))


def _save_figure(rows: list[dict[str, Any]], path: Path) -> None:
	scenarios = list(dict.fromkeys(row["scenario"] for row in rows))
	positions = np.arange(len(scenarios))
	qber_means = [_mean([r["q_hat"] for r in rows if r["scenario"] == name]) for name in scenarios]
	upper_means = [_mean([r["q_upper"] for r in rows if r["scenario"] == name]) for name in scenarios]
	key_means = [_mean([r["final_key_length"] for r in rows if r["scenario"] == name]) for name in scenarios]
	abort_rates = [
		sum(r["status"] == "aborted" for r in rows if r["scenario"] == name)
		/ sum(r["scenario"] == name for r in rows)
		for name in scenarios
	]
	width = 0.36
	fig, axes = plt.subplots(3, 1, figsize=(max(10, len(scenarios) * 1.5), 12))
	axes[0].bar(positions - width / 2, [v or 0.0 for v in qber_means], width, label="Observed q_hat")
	axes[0].bar(positions + width / 2, [v or 0.0 for v in upper_means], width, label="q_upper")
	axes[0].axhline(0.11, color="red", linestyle="--", linewidth=1, label="Abort threshold 0.11")
	axes[0].set_ylabel("QBER bound")
	axes[0].legend()
	axes[1].bar(positions, [v or 0.0 for v in key_means], color="seagreen")
	axes[1].set_ylabel("Mean final key bits")
	axes[2].bar(positions, abort_rates, color="indianred")
	axes[2].set_ylabel("Abort rate")
	axes[2].set_ylim(0, 1)
	for axis in axes:
		axis.set_xticks(positions, scenarios, rotation=25, ha="right")
		axis.grid(axis="y", alpha=0.25)
	axes[2].set_xlabel("Scenario")
	fig.suptitle("Educational BB84 experiment outcomes")
	fig.tight_layout()
	fig.savefig(path, dpi=160)
	plt.close(fig)


def _self_test() -> None:
	"""Run focused protocol tests, including deliberately forced failures."""
	rng = np.random.default_rng(912)

	# Measurement rules: matching bases preserve bits; opposite-basis outcomes
	# disagree with the prepared bits approximately half the time.
	matching_session = AliceSession(128, 0.0, 0.0, 10)
	matching_bases = matching_session._alice_bases.copy()
	matching_bits = matching_session._alice_bits.copy()
	assert np.array_equal(matching_session.transmit(matching_bases), matching_bits)
	opposite_session = AliceSession(4096, 0.0, 0.0, 11)
	opposite_bases = 1 - opposite_session._alice_bases
	opposite_received = opposite_session.transmit(opposite_bases)
	opposite_error = np.mean(opposite_received != opposite_session._alice_bits)
	assert 0.46 < opposite_error < 0.54

	# Sample removal alignment: Bob removes the same sifted positions and the
	# parity over the aligned remaining vector equals Alice's public parity.
	alignment_session = AliceSession(128, 0.0, 0.0, 12)
	alignment_bases = alignment_session._alice_bases.copy()
	alignment_received = alignment_session.transmit(alignment_bases)
	alignment_session.reveal_bases()
	all_indices = np.arange(128, dtype=np.int64)
	alignment_session.sift(all_indices)
	positions, disclosed = alignment_session.disclose_sample(16)
	assert np.array_equal(disclosed, alignment_received[positions])
	alignment_bob_key = alignment_received.copy()
	keep = np.ones(alignment_bob_key.size, dtype=bool)
	keep[positions] = False
	alignment_bob_key = alignment_bob_key[keep]
	alignment_session.remove_sample()
	assert int(np.bitwise_xor.reduce(alignment_bob_key, initial=np.uint8(0))) == alignment_session.parity(
		np.arange(alignment_bob_key.size)
	)

	# Known one-bit discrepancy: a test-only Bob copy is flipped; Cascade must
	# repair it using only parity responses. Singleton parity checks are used
	# afterward by the test harness, not by the correction algorithm.
	error_session = AliceSession(512, 0.0, 0.0, 13)
	error_bases = error_session._alice_bases.copy()
	error_received = error_session.transmit(error_bases)
	error_session.reveal_bases()
	error_session.sift(np.arange(512, dtype=np.int64))
	error_positions, _ = error_session.disclose_sample(32)
	error_keep = np.ones(512, dtype=bool)
	error_keep[error_positions] = False
	error_bob_key = error_received[error_keep].copy()
	error_session.remove_sample()
	flip_at = int(rng.integers(0, error_bob_key.size))
	error_bob_key[flip_at] ^= np.uint8(1)
	query_counter = [0]
	correction_counter = [0]
	bob_module._cascade_correct(
		error_session, error_bob_key, 0.05, BobConfig(), query_counter, correction_counter
	)
	assert correction_counter[0] >= 1
	assert all(
		int(error_bob_key[index]) == error_session.parity([index])
		for index in range(error_bob_key.size)
	)

	# Optimized and reference Toeplitz implementations agree on small cases.
	for input_length in range(1, 16):
		for output_length in range(1, 12):
			bits = rng.integers(0, 2, input_length, dtype=np.uint8)
			seed_bits = rng.integers(0, 2, input_length + output_length - 1, dtype=np.uint8)
			assert np.array_equal(
				toeplitz_hash(bits, seed_bits, output_length),
				toeplitz_hash_reference(bits, seed_bits, output_length),
			)

	# Insufficient sifting aborts without trying to disclose an invalid sample.
	insufficient = run_bob(AliceSession(2, 0.0, 0.0, 14), 2, 2, 15, BobConfig())
	assert insufficient.status == "aborted" and "insufficient sifted bits" in insufficient.abort_reason

	# Force every tag to mismatch so Bob reaches the three-attempt abort path.
	class AlwaysWrongTagSession(AliceSession):
		def verification_tag(self, seed_bits: Any, tag_length: int) -> np.ndarray:
			tag = super().verification_tag(seed_bits, tag_length)
			if tag.size:
				tag[0] ^= np.uint8(1)
			return tag

	loose_config = BobConfig(
		epsilon_pe=0.99,
		epsilon_pa=0.99,
		verification_tag_length=8,
		max_parity_queries=20_000,
	)
	verification_failure = run_bob(
		AlwaysWrongTagSession(5000, 0.0, 0.0, 16), 5000, 500, 17, loose_config
	)
	assert verification_failure.status == "aborted"
	assert verification_failure.verification_attempts == 3
	assert verification_failure.verification_leak_bits == 24

	# Successful OTP demonstration uses a fresh run and enough key bits.
	message_args = argparse.Namespace(message="BB84 test")
	message_session = AliceSession(5000, 0.0, 0.0, 18)
	message_result = run_bob(message_session, 5000, 500, 19, loose_config)
	assert message_result.status == "key established under the challenge model", message_result.abort_reason
	alice_key = message_session.final_key(message_result.privacy_seed, message_result.final_length)
	demo = _message_demo(message_args.message, alice_key, message_result.final_key)
	assert demo["roundtrip_ok"] and demo["status"] == "completed"

	print("Self-test passed: measurement, alignment, Cascade correction, Toeplitz, aborts, and OTP demo.")


def main(argv: list[str] | None = None) -> None:
	args = _parse_args(argv)
	if args.self_test:
		_self_test()
		return

	scenarios = SUITE if args.suite else [{
		"name": "custom",
		"noise_rate": args.noise_rate,
		"eve_fraction": args.eve_fraction,
	}]
	output_dir = args.output_dir
	output_dir.mkdir(parents=True, exist_ok=True)
	seed_rows = _derive_seeds(args.seed, len(scenarios) * args.trials)
	rows: list[dict[str, Any]] = []
	message_results = []
	seed_index = 0

	for scenario in scenarios:
		for trial_number in range(1, args.trials + 1):
			seeds = seed_rows[seed_index]
			seed_index += 1
			row, message_result = _run_trial(
				scenario, trial_number, args, seeds, output_dir
			)
			rows.append(row)
			if message_result:
				message_results.append({
					"scenario": scenario["name"],
					"trial": trial_number,
					**message_result,
				})
			print(
				f"{scenario['name']} trial {trial_number}: {row['status']}; "
				f"q_hat={row['q_hat']}; q_upper={row['q_upper']}; "
				f"final_bits={row['final_key_length']}; runtime={row['runtime_seconds']:.2f}s"
			)

	_write_results(rows, output_dir / "results.csv")
	_aggregate_results = _aggregate(rows)
	_save_figure(rows, output_dir / "bb84_results.png")
	metadata = {
		"configuration": {
			"signals": args.signals,
			"sample_size": args.sample_size,
			"noise_rate": args.noise_rate,
			"eve_fraction": args.eve_fraction,
			"trials_per_scenario": args.trials,
			"master_seed": args.seed,
			"suite": args.suite,
			"message_demo_requested": args.message is not None,
			"message_utf8_bytes": None if args.message is None else len(args.message.encode("utf-8")),
			"private_keys_saved": False,
			"public_channel_assumption": "authenticated",
			"model_limitations": [
				"Classical simulation, not real quantum communication.",
				"Hoeffding parameter bound and privacy length are simplified challenge formulas, not a complete security proof.",
				"Observed QBER is treated conservatively and does not identify its cause.",
				"Simulation seeds are recorded for reproducibility; publishing them makes runs predictable.",
				"OTP message demonstration provides no authentication.",
			],
		},
		"library_versions": {
			"python": sys.version.split()[0],
			"numpy": np.__version__,
			"bob_module": getattr(bob_module, "__file__", None),
			"channel_module": getattr(channel_module, "__file__", None),
		},
		"simulation_seeds": [
			{
				"scenario": scenario["name"],
				"trial": trial_number,
				**seed_rows[index],
			}
			for index, (scenario, trial_number) in enumerate(
				(scenario, trial_number)
				for scenario in scenarios
				for trial_number in range(1, args.trials + 1)
			)
		],
		"aggregate_results": _aggregate_results,
		"message_demonstrations": message_results,
		"expected_qber_by_scenario": {
			scenario["name"]: (
				scenario["noise_rate"]
				+ scenario["eve_fraction"] / 4
				- 2 * scenario["noise_rate"] * (scenario["eve_fraction"] / 4)
			)
			for scenario in scenarios
		},
		"output_files": [
			"results.csv", "summary.json", "bb84_results.png", "public_transcripts/*.json"
		],
	}
	with (output_dir / "summary.json").open("w", encoding="utf-8") as summary_file:
		json.dump(metadata, summary_file, indent=2)
		summary_file.write("\n")
	print(f"\nSaved results, metadata, plot, and public transcripts under {output_dir}")
	print("OTP mode is a simulated one-time pad and does not provide message authentication.")
	print("Simulation seeds are in summary.json; publishing them makes this simulation predictable.")


if __name__ == "__main__":
	main()
