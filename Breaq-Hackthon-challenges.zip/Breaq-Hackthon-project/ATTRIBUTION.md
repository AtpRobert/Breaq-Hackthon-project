# Sources and attribution

Organizer materials come from [RoQTeam/BreaQ-2026-challenges](https://github.com/RoQTeam/BreaQ-2026-challenges).
The upstream Apache 2.0 license is included as `LICENSE`. Organizer briefs and service
modules retain their source content. Completed notebooks, local experiments and
presentations document this workspace's work, including Codex assistance.

The local CH1 corrected notebook replaces the earlier draft for presentation purposes.
All claims refer to local simulations and recorded evidence. The Shor implementation
is a teaching prototype and does not satisfy the full circuit-building challenge.
The hardware challenge has no public brief or measurements in the supplied materials.
