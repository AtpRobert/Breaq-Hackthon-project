"""Extract existing CH1 plots and generate only missing challenge figures.

Run with a Python environment containing Matplotlib. Existing PNGs are preserved.
The hardware figure documents missing supplied materials, not device performance.
"""
import base64
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
CHALLENGES = ROOT / "challenges"


def main():
    ch1 = CHALLENGES / "01_trust_no_input"
    notebook = json.loads((ch1 / "01_solution.ipynb").read_text())
    names = {14: "fingerprint_comparison.png", 16: "compatibility_map.png"}
    for index, filename in names.items():
        destination = ch1 / "results" / filename
        if destination.exists():
            continue
        for output in notebook["cells"][index].get("outputs", []):
            encoded = output.get("data", {}).get("image/png")
            if encoded:
                destination.parent.mkdir(exist_ok=True)
                destination.write_bytes(base64.b64decode("".join(encoded)))
                print("Extracted existing notebook plot:", destination.relative_to(ROOT))
                break
        else:
            raise ValueError(f"No existing plot in CH1 cell {index}")

    shor = CHALLENGES / "05_shor_in_miniature"
    plot_path = shor / "period_finding.png"
    if not plot_path.exists():
        fig, axes = plt.subplots(1, 2, figsize=(11, 4.2), layout="constrained")
        data = []
        for ax, modulus, period in zip(axes, (15, 21), (4, 6)):
            steps = list(range(13))
            residues = [pow(2, step, modulus) for step in steps]
            # These are direct arithmetic values, not quantum-hardware measurements.
            data.extend({"modulus": modulus, "base": 2, "exponent": x, "remainder": y}
                        for x, y in zip(steps, residues))
            ax.plot(steps, residues, "o-", color="#176b87", linewidth=2)
            ax.axhline(1, color="#999999", linestyle=":", linewidth=1)
            ax.plot(period, 1, "o", color="#d1495b", markersize=10,
                    label=f"First positive return to 1: r={period}")
            ax.set(title=f"2^x mod {modulus}", xlabel="Exponent x", ylabel="Remainder")
            ax.set_xticks(steps[::2])
            ax.grid(alpha=0.2)
            ax.legend(loc="upper left", fontsize=9)
        fig.suptitle("Shor teaching example: repeated modular powers", fontsize=15)
        fig.savefig(plot_path, dpi=170)
        plt.close(fig)
        (shor / "period_plot_data.json").write_text(json.dumps({
            "description": "Direct modular arithmetic illustration, not sampled circuit output",
            "rows": data,
        }, indent=2) + "\n")
        print("Generated:", plot_path.relative_to(ROOT))

    hardware = CHALLENGES / "06_hardware_surprise"
    status_path = hardware / "materials_status.png"
    if not status_path.exists():
        labels = ["Public challenge brief", "Equipment instructions", "Recorded measurements"]
        # All three are absent from the supplied public materials/workspace.
        fig, ax = plt.subplots(figsize=(9, 3.8), layout="constrained")
        ax.scatter([0] * len(labels), list(range(len(labels))), s=130, marker="s", color="#d28d26")
        ax.set_yticks(range(len(labels)), labels)
        ax.set_xticks([0, 1], ["Not supplied", "Supplied"])
        ax.set_xlim(-0.25, 1.25)
        ax.set_ylim(2.5, -0.5)
        ax.grid(axis="x", alpha=0.2)
        ax.set_title("Hardware Surprise: documentation status", fontsize=15, pad=20)
        ax.set_xlabel("Supplied public repository and local workspace only")
        for spine in ("top", "right", "left"):
            ax.spines[spine].set_visible(False)
        fig.savefig(status_path, dpi=170)
        plt.close(fig)
        print("Generated documentation-status figure:", status_path.relative_to(ROOT))


if __name__ == "__main__":
    main()
