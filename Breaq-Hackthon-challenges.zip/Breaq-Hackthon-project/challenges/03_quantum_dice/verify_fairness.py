"""Check CSV bit streams for frequency bias and adjacent dependence.

These checks test compatibility with an IID fair-bit null; they cannot prove
fairness, unpredictability, or cryptographic security. They may also miss
patterns not measured by frequency or adjacent repetition.
"""

import argparse
import csv
import math
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import binomtest


REQUIRED_COLUMNS = {"batch_id", "bit_index", "bit"}


class InputError(ValueError):
	"""Raised when an input CSV is not a valid ordered bit stream."""


def read_batches(csv_path: Path) -> list[dict[str, Any]]:
	"""Load, validate, and order batches from one CSV file."""
	grouped: dict[str, list[tuple[int, int]]] = {}
	seen_indices: dict[str, set[int]] = {}

	try:
		with csv_path.open("r", newline="", encoding="utf-8-sig") as csv_file:
			reader = csv.DictReader(csv_file)
			if reader.fieldnames is None:
				raise InputError(f"{csv_path}: CSV has no header")
			missing_columns = REQUIRED_COLUMNS - set(reader.fieldnames)
			if missing_columns:
				raise InputError(
					f"{csv_path}: missing required columns: {', '.join(sorted(missing_columns))}"
				)

			for line_number, row in enumerate(reader, start=2):
				batch_id = (row.get("batch_id") or "").strip()
				if not batch_id:
					raise InputError(f"{csv_path}:{line_number}: batch_id cannot be empty")
				try:
					bit_index = int(row["bit_index"])
				except (TypeError, ValueError) as error:
					raise InputError(
						f"{csv_path}:{line_number}: bit_index must be an integer"
					) from error
				if bit_index < 0:
					raise InputError(f"{csv_path}:{line_number}: bit_index must be non-negative")

				bit_text = (row.get("bit") or "").strip()
				if bit_text not in {"0", "1"}:
					raise InputError(f"{csv_path}:{line_number}: bit must be exactly 0 or 1")
				bit = int(bit_text)

				indices = seen_indices.setdefault(batch_id, set())
				if bit_index in indices:
					raise InputError(
						f"{csv_path}:{line_number}: duplicate bit_index {bit_index} "
						f"in batch {batch_id}"
					)
				indices.add(bit_index)
				grouped.setdefault(batch_id, []).append((bit_index, bit))
	except OSError as error:
		raise InputError(f"Cannot read {csv_path}: {error}") from error

	if not grouped:
		raise InputError(f"{csv_path}: CSV contains no bit rows")

	batches = []
	for batch_id, indexed_bits in grouped.items():
		indexed_bits.sort(key=lambda item: item[0])
		indices = [index for index, _ in indexed_bits]
		expected_indices = list(range(len(indices)))
		if indices != expected_indices:
			missing = sorted(set(expected_indices) - set(indices))
			extra = sorted(set(indices) - set(expected_indices))
			details = []
			if missing:
				details.append(f"missing indices {missing}")
			if extra:
				details.append(f"indices outside 0..{len(indices) - 1}: {extra}")
			raise InputError(
				f"{csv_path}: batch {batch_id} indices must be contiguous from 0 "
				f"({'; '.join(details)})"
			)
		batches.append({
			"filename": str(csv_path),
			"batch_id": batch_id,
			"bits": [bit for _, bit in indexed_bits],
		})
	return batches


def _holm_adjust(p_values: list[float]) -> list[float]:
	"""Return Holm step-down adjusted p-values in their original order."""
	if not p_values:
		return []
	order = sorted(range(len(p_values)), key=p_values.__getitem__)
	adjusted = [0.0] * len(p_values)
	previous = 0.0
	test_count = len(p_values)
	for rank, original_index in enumerate(order):
		candidate = min(1.0, (test_count - rank) * p_values[original_index])
		previous = max(previous, candidate)
		adjusted[original_index] = previous
	return adjusted


def analyze_batches(batches: list[dict[str, Any]], alpha: float) -> list[dict[str, Any]]:
	"""Calculate batch metrics and adjust all available tests together."""
	results = []
	raw_p_values = []
	result_test_slots: list[tuple[int, str]] = []

	for batch in batches:
		bits = batch["bits"]
		bit_count = len(bits)
		ones = sum(bits)
		fraction_ones = ones / bit_count
		balance_p = float(binomtest(ones, bit_count, p=0.5, alternative="two-sided").pvalue)

		if bit_count >= 2:
			matching_pairs = sum(left == right for left, right in zip(bits, bits[1:]))
			pair_count = bit_count - 1
			repeat_fraction = matching_pairs / pair_count
			predictor_accuracy = repeat_fraction
			repetition_p = float(
				binomtest(matching_pairs, pair_count, p=0.5, alternative="two-sided").pvalue
			)
		else:
			matching_pairs = 0
			repeat_fraction = None
			predictor_accuracy = None
			repetition_p = None

		result = {
			**{key: batch[key] for key in ("filename", "batch_id")},
			"bit_count": bit_count,
			"zero_count": bit_count - ones,
			"one_count": ones,
			"fraction_ones": fraction_ones,
			"deviation_from_half": fraction_ones - 0.5,
			"repeat_count": matching_pairs if bit_count >= 2 else None,
			"pair_count": bit_count - 1 if bit_count >= 2 else None,
			"repeat_fraction": repeat_fraction,
			"predictor_accuracy": predictor_accuracy,
			"balance_p_raw": balance_p,
			"balance_p_holm": None,
			"repeat_p_raw": repetition_p,
			"repeat_p_holm": None,
			"balance_flag": False,
			"repeat_flag": False,
			"repeat_check_status": "tested" if bit_count >= 2 else "insufficient data",
		}
		results.append(result)
		result_test_slots.append((len(results) - 1, "balance_p_holm"))
		raw_p_values.append(balance_p)
		if repetition_p is not None:
			result_test_slots.append((len(results) - 1, "repeat_p_holm"))
			raw_p_values.append(repetition_p)

	for (result_index, adjusted_field), adjusted_p in zip(
		result_test_slots, _holm_adjust(raw_p_values)
	):
		results[result_index][adjusted_field] = adjusted_p

	for result in results:
		result["balance_flag"] = result["balance_p_holm"] < alpha
		if result["repeat_p_holm"] is not None:
			result["repeat_flag"] = result["repeat_p_holm"] < alpha
		flags = []
		if result["balance_flag"]:
			flags.append("frequency")
		if result["repeat_flag"]:
			flags.append("repetition")
		result["flags"] = ";".join(flags) if flags else "none"
		result["anomaly"] = bool(flags)
	return results


def write_report(results: list[dict[str, Any]], output_path: Path) -> None:
	fieldnames = [
		"filename", "batch_id", "bit_count", "zero_count", "one_count",
		"fraction_ones", "deviation_from_half", "repeat_count", "pair_count",
		"repeat_fraction", "predictor_accuracy", "balance_p_raw", "balance_p_holm",
		"repeat_p_raw", "repeat_p_holm", "balance_flag", "repeat_flag",
		"repeat_check_status", "flags", "anomaly",
	]
	with output_path.open("w", newline="", encoding="utf-8") as report_file:
		writer = csv.DictWriter(report_file, fieldnames=fieldnames)
		writer.writeheader()
		writer.writerows(results)


def save_plot(results: list[dict[str, Any]], output_path: Path) -> None:
	labels = [f"{Path(row['filename']).name}\n{row['batch_id']}" for row in results]
	x_values = np.arange(len(results))
	width = 0.38
	frequency_values = [row["fraction_ones"] for row in results]
	repeat_values = [
		row["repeat_fraction"] if row["repeat_fraction"] is not None else math.nan
		for row in results
	]

	fig_width = max(9, min(24, len(results) * 0.6))
	fig, axis = plt.subplots(figsize=(fig_width, 5))
	axis.bar(x_values - width / 2, frequency_values, width, label="Fraction of ones")
	axis.bar(x_values + width / 2, repeat_values, width, label="Repeat fraction")
	axis.axhline(0.5, color="black", linestyle="--", linewidth=1, label="IID fair-bit reference (0.5)")
	axis.set_ylim(0, 1)
	axis.set_ylabel("Fraction")
	axis.set_xlabel("Input file and batch ID")
	axis.set_title("Bit-stream frequency and adjacent repetition by batch")
	axis.set_xticks(x_values, labels, rotation=70, ha="right")
	axis.legend()
	fig.tight_layout()
	fig.savefig(output_path, dpi=150)
	plt.close(fig)


def _format_p(value: float | None) -> str:
	return "n/a" if value is None else f"{value:.4g}"


def print_summary(results: list[dict[str, Any]], alpha: float) -> None:
	for row in results:
		print(
			f"{row['filename']} | batch {row['batch_id']} | n={row['bit_count']} | "
			f"ones={row['fraction_ones']:.4f} "
			f"(deviation={row['deviation_from_half']:+.4f}) | "
			f"repeat={row['repeat_fraction'] if row['repeat_fraction'] is not None else 'n/a'} | "
			f"predictor={row['predictor_accuracy'] if row['predictor_accuracy'] is not None else 'n/a'} | "
			f"p balance raw/holm={_format_p(row['balance_p_raw'])}/"
			f"{_format_p(row['balance_p_holm'])} | "
			f"p repeat raw/holm={_format_p(row['repeat_p_raw'])}/"
			f"{_format_p(row['repeat_p_holm'])} | flags={row['flags']}"
		)
		if row["repeat_check_status"] == "insufficient data":
			print("  Repetition check: insufficient data (fewer than two bits).")
		if row["predictor_accuracy"] is not None:
			print(
				"  Previous-bit predictor accuracy equals repeat_fraction; it is not "
				"an additional independent test. Below-0.5 accuracy can suggest an "
				"alternating pattern exploitable by predicting the opposite bit."
			)
			print(
				"  A stream can be balanced overall and still fail the adjacent-repetition check."
			)
		print(
			"  Both tests assume independent fair bits under the null. A frequency-test "
			"rejection alone does not distinguish marginal bias from dependence."
		)

	print("\nFlagged batches by file:")
	for filename in dict.fromkeys(row["filename"] for row in results):
		file_rows = [row for row in results if row["filename"] == filename]
		flagged_count = sum(row["anomaly"] for row in file_rows)
		print(f"  {filename}: {flagged_count}/{len(file_rows)}")

	if any(row["anomaly"] for row in results):
		print(f"\nAnomaly detected (Holm-adjusted p-value < alpha={alpha:g}).")
	else:
		print(f"\nNo anomaly detected by these checks (alpha={alpha:g}).")
	print(
		"Finite samples cannot prove fairness or unpredictability, and these checks "
		"can miss other patterns. A passing result is not proof of fairness or security."
	)


def main() -> None:
	parser = argparse.ArgumentParser(
		description="Check CSV bit streams for frequency and adjacent-repeat anomalies."
	)
	parser.add_argument("csv_paths", nargs="+", type=Path, help="one or more input CSV files")
	parser.add_argument("--alpha", type=float, default=0.01,
					 help="significance level in (0, 1), default: 0.01")
	args = parser.parse_args()
	if not 0.0 < args.alpha < 1.0:
		parser.error("--alpha must be between 0 and 1, exclusive")

	try:
		batches = [batch for csv_path in args.csv_paths for batch in read_batches(csv_path)]
	except InputError as error:
		parser.error(str(error))

	results = analyze_batches(batches, args.alpha)
	write_report(results, Path("fairness_report.csv"))
	save_plot(results, Path("fairness_plot.png"))
	print_summary(results, args.alpha)
	print("\nSaved fairness_report.csv and fairness_plot.png in the current directory.")


if __name__ == "__main__":
	main()