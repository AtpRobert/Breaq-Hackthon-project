# Challenge 2 progress

Steps 1-3 and the remaining investigation are complete locally.

See [CHALLENGE_REPORT.txt](CHALLENGE_REPORT.txt) for the full measured results,
limitations, artifact list and reproduction instructions.

Run `.venv/bin/python run_challenge.py` to execute and rebuild the submission.
